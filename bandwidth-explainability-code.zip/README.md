# Bandwidth explainability

Explainability code, notebooks, saved Grad-CAM results, validation images, and
research reports for the original **Low / High bandwidth** classifiers.
The original split is **176 training / 45 validation / no independent test set**.
Saved explanations describe model behavior; they do not establish physical causality.
This task is separate from SUTD/RDN compact-response classification.

## Download the full supporting collection

[Download the full collection](https://github.com/OldJake667/bandwidth-explainability/releases/download/v1.0.0/bandwidth-explainability-full.zip)
from the [v1.0.0 release](https://github.com/OldJake667/bandwidth-explainability/releases/tag/v1.0.0).
It contains all saved LIME/rollout outputs, Grad-CAM arrays, images, figures,
provenance records, and reports (about 1.38 GB uncompressed). Extract it into
this repository's root before running analyses that need supporting data.
The repository itself provides the source code, notebooks, instructions, and PDFs.
Model checkpoints are excluded from both the repository and release download.

## Materials

- [LIME, attention rollout, and gradient attention rollout notebooks](model-training/original-bandwidth-replication/undated/local-work/original_bandwidth_explainability_lab/START_HERE.md)
- [Grad-CAM code, notebook, and saved numerical results](model-training/rdn-pretrained-finetuning/2026-10-16_to_2026-10-19/local-work/gradcam_xai/)
- [Research reports and figures](XAI/README.md)
- [Final Grad-CAM presentation](<XAI/research-progress/2026-10-19_to_2026-10-23/bandwidth-pattern-guide/gradcam-friday/presentation 26 - 30.10.26.pdf>)
- [Expanded structural atlas](XAI/research-progress/2026-10-19_to_2026-10-23/bandwidth-pattern-guide/expanded-cases/expanded-structural-atlas.pdf)
- [Full saved LIME and rollout outputs (release download)](https://github.com/OldJake667/bandwidth-explainability/releases/download/v1.0.0/bandwidth-explainability-full.zip)

The folder layout is preserved because the analysis scripts use these relative
paths. The full saved LIME and rollout outputs and the original 221 image inputs are included.
No Python environment, credentials, model weights, or full RDN training dataset
is included. Third-party licenses are retained with the lab package.

## Running the analyses

Follow the lab's `START_HERE.md` for its Python dependencies and GPU-specific
setup. Its original package instructions describe the complete local package;
this GitHub export excludes checkpoint weights. For the notebook package you use, restore the five exact model
files listed in [supporting-resources.json](supporting-resources.json) before
running model inference or checkpoint-integrity checks. All expected checksums
remain in the original integrity manifests.

The 45 validation BMPs are included in both notebook packages. The original
221-image dataset and its split manifest are also included under
`model-training/original-bandwidth-replication/undated/local-work/data/`.
Model-based regeneration of the atlas or Grad-CAM figures requires the restored
checkpoints. The recorded resources and checkpoint checksums are in
`supporting-resources.json`.

Historical verification files record their original runs and source hashes.
They are not a claim that CUDA or full LIME execution was verified on this Mac.
