"""Render an evidence-based pattern guide from existing images and XAI arrays."""

import csv
import hashlib
import json
from pathlib import Path
import subprocess
import textwrap

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.patches import FancyArrowPatch, Rectangle
from matplotlib.ticker import PercentFormatter
import numpy as np
from PIL import Image

from analyze_patterns import HERE, PROJECT, RESEARCH

SUMMARY = json.loads((HERE / "analysis.json").read_text())
ROWS = list(csv.DictReader((HERE / "image_features.csv").open(newline="")))
BY_ID = {row["file"].split("_")[0]: row for row in ROWS}
LATEST = HERE.parent / "updates_19-23_october_2026_latex"
CONTROLS = json.loads((LATEST / "structural_mask_checks.json").read_text())["cases"]
CAM_ROOT = (
    RESEARCH
    / "model-training/rdn-pretrained-finetuning/2026-10-16_to_2026-10-19/local-work/gradcam_xai/results/53bd12555dbda8d0/dinov2"
)
COLORS = {
    "Low": "#007d83",
    "High": "#b65e00",
    "ink": "#172b3b",
    "muted": "#536473",
    "line": "#c9d1d8",
    "error": "#b32635",
}
plt.rcParams.update(
    {
        "font.family": "DejaVu Sans",
        "font.size": 11,
        "axes.titlesize": 13,
        "axes.labelsize": 11,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "pdf.fonttype": 42,
        "svg.fonttype": "none",
        "axes.unicode_minus": False,
    }
)
QA = HERE / "tmp/pdfs"
QA.mkdir(parents=True, exist_ok=True)


def image(sample):
    return np.asarray(Image.open(RESEARCH / BY_ID[sample]["image_path"]).convert("L"))


def figure(title, subtitle, page):
    fig = plt.figure(figsize=(13.8, 9.7), facecolor="white")
    fig.text(0.05, 0.955, title, color=COLORS["ink"], fontsize=23, weight="bold", va="top")
    fig.text(0.05, 0.91, subtitle, color=COLORS["muted"], fontsize=11.5, va="top")
    fig.text(
        0.05,
        0.027,
        "Original bandwidth dataset | 176 train / 45 validation | Exploratory analysis, 26 October 2026",
        fontsize=9,
        color=COLORS["muted"],
    )
    fig.text(0.95, 0.027, str(page), ha="right", fontsize=9, color=COLORS["muted"])
    return fig


def show_pattern(fig, box, sample, title):
    ax = fig.add_axes(box)
    ax.imshow(image(sample), cmap="gray", vmin=0, vmax=255)
    ax.set_axis_off()
    ax.set_title(title, loc="left", fontsize=14, pad=9, color=COLORS[BY_ID[sample]["class_name"]])
    return ax


def dictionary():
    fig = figure(
        "Visual fingerprints to look for",
        "Real labelled designs. These cues describe tendencies in this dataset; none is a universal bandwidth test.",
        1,
    )
    ids = {
        label: filename.split("_")[0]
        for label, filename in SUMMARY[
            "representatives_selected_nearest_training_class_median_dark_coverage"
        ].items()
    }
    for label, x in [("Low", 0.06), ("High", 0.54)]:
        sample = ids[label]
        ax = show_pattern(fig, [x, 0.385, 0.40, 0.47], sample, f"{label} example: {sample}")
        ax.add_patch(
            Rectangle((30, 532), 710, 209, fill=False, edgecolor=COLORS[label], linewidth=2)
        )
        crop = fig.add_axes([x, 0.195, 0.40, 0.16])
        crop.imshow(image(sample)[532:741, 30:740], cmap="gray", vmin=0, vmax=255)
        crop.set_axis_off()
        crop.set_title(
            "Zoom: lower branch region", loc="left", fontsize=10.5, color=COLORS["muted"], pad=5
        )
        caption = (
            "Separated pieces and open gaps"
            if label == "Low"
            else "Broader, more continuous lower arm"
        )
        fig.text(x, 0.16, caption, fontsize=13, weight="bold", color=COLORS[label])
        coverage = float(BY_ID[sample]["dark_coverage"])
        fig.text(
            x,
            0.125,
            f"Black-equivalent image coverage: {coverage:.1%}",
            fontsize=11,
            color=COLORS["ink"],
        )
    fig.text(
        0.06,
        0.073,
        'Closest analogy: fragmentation + coverage + continuity form a visual fingerprint, rather than one decisive "nose".',
        fontsize=11,
        color=COLORS["ink"],
    )
    return fig


def evidence():
    fig = figure(
        "How well do these visible cues separate the labels?",
        "Every threshold is fitted on training records only. This reused validation split is exploratory, not an independent test.",
        2,
    )
    ax = fig.add_axes([0.09, 0.47, 0.48, 0.34])
    rng = np.random.RandomState(42)
    for label, y in [("Low", 0), ("High", 1)]:
        for split, marker, size, alpha in [("train", "o", 16, 0.25), ("validation", "D", 34, 0.85)]:
            rows = [r for r in ROWS if r["class_name"] == label and r["split"] == split]
            values = [float(r["dark_coverage"]) for r in rows]
            ax.scatter(
                values,
                y + rng.uniform(-0.12, 0.12, len(rows)),
                color=COLORS[label],
                marker=marker,
                s=size,
                alpha=alpha,
                linewidths=0,
                label=split if label == "Low" else None,
            )
    threshold = SUMMARY["features"]["dark_coverage"]["threshold"]
    ax.axvline(threshold, color=COLORS["ink"], linestyle="--", linewidth=1)
    ax.text(
        threshold + 0.004, 0.53, f"Training threshold\n{threshold:.2%}", fontsize=10, va="center"
    )
    for sample, target_y, text_y in [("M93", 0, -0.39), ("M178", 1, 1.37)]:
        value = float(BY_ID[sample]["dark_coverage"])
        ax.plot(value, target_y, "o", ms=11, mfc="none", mec=COLORS["error"], mew=1.6)
        ax.annotate(
            sample + ": exception",
            (value, target_y),
            (value + 0.025, text_y),
            fontsize=10,
            color=COLORS["error"],
            arrowprops={"arrowstyle": "-", "color": COLORS["error"]},
        )
    ax.set(
        yticks=[0, 1],
        yticklabels=["True Low", "True High"],
        ylim=(-0.55, 1.6),
        xlabel="Black-equivalent coverage = 1 - mean gray / 255",
    )
    ax.xaxis.set_major_formatter(PercentFormatter(1, decimals=0))
    ax.legend(loc="upper left", fontsize=9, frameon=False, ncol=2)
    ax.set_title("Whole-image darkness is a strong cue", loc="left", pad=12)
    bar = fig.add_axes([0.70, 0.435, 0.24, 0.38])
    names = [
        "dark_coverage",
        "lower_black_fraction",
        "small_island_fraction",
        "largest_component_fraction",
        "lower_component_span",
        "substantial_components",
    ]
    labels = [
        "Global coverage",
        "Lower-region area",
        "Small-island fraction",
        "Largest component",
        "Lower-arm span",
        "Number of pieces",
    ]
    scores = [SUMMARY["features"][name]["validation_correct"] for name in names]
    bar.barh(np.arange(6), scores, color="#578196", height=0.57)
    bar.set(
        yticks=np.arange(6),
        yticklabels=labels,
        xlim=(0, 49),
        xticks=[0, 15, 30, 45],
        xlabel="Correct / 45 validation images",
    )
    bar.invert_yaxis()
    bar.spines["left"].set_visible(False)
    bar.tick_params(axis="y", length=0, labelsize=10)
    for index, value in enumerate(scores):
        bar.text(value + 0.6, index, str(value), va="center", fontsize=11)
    bar.set_title("One visible descriptor at a time", fontsize=12, loc="left", pad=12)
    fig.text(
        0.08,
        0.30,
        "Simple rule: coverage >= 20.67% predicts High",
        fontsize=16,
        weight="bold",
        color=COLORS["ink"],
    )
    fig.text(
        0.08,
        0.25,
        "170/176 training labels and 43/45 validation labels agree. Exceptions: M93 (Low) and M178 (High).",
        fontsize=11.5,
    )
    fig.text(
        0.08,
        0.205,
        "Training class means: coverage 14.48% Low vs 25.38% High; small-island share 17.82% Low vs 7.48% High.",
        fontsize=11,
    )
    fig.text(
        0.08,
        0.16,
        "DINOv2 also matches 43/45 validation labels, but its errors are M93 and M95. Similar accuracy is not identical reasoning.",
        fontsize=11,
    )
    fig.text(
        0.08,
        0.108,
        "Coverage and archived DINOv2 High scores have Spearman correlation 0.945 across these 45 images.",
        fontsize=11,
    )
    fig.text(
        0.08,
        0.075,
        "This is association. Coverage alone does not establish an optical mechanism or generalization to a new design family.",
        fontsize=10.5,
        color=COLORS["muted"],
    )
    return fig


def mistakes():
    fig = figure(
        "What the latest error heatmaps actually explain",
        "Both designs below are truly labelled Low. The saved DINOv2 explanations describe two wrong High predictions.",
        3,
    )
    for case, y in zip(CONTROLS, [0.535, 0.13]):
        sample = case["sample"]
        ax = show_pattern(fig, [0.05, y, 0.275, 0.31], sample, f"{sample}: true Low")
        point = (560, 610) if sample == "M93" else (660, 190)
        location = (75, 260) if sample == "M93" else (65, 280)
        label = "Long lower-right arm" if sample == "M93" else "Upper-right prongs"
        ax.annotate(
            label,
            point,
            location,
            fontsize=9,
            color=COLORS["error"],
            bbox={"facecolor": "white", "edgecolor": "none", "alpha": 0.9, "pad": 2},
            arrowprops={"arrowstyle": "->", "color": COLORS["error"], "lw": 1.4},
        )
        maps = np.load(CAM_ROOT / Path(BY_ID[sample]["file"]).stem / "maps.npz")
        overlay = fig.add_axes([0.365, y, 0.275, 0.31])
        overlay.imshow(image(sample), cmap="gray", vmin=0, vmax=255)
        overlay.imshow(maps["high_upsampled"], cmap="magma", vmin=0, vmax=1, alpha=0.55)
        overlay.set_axis_off()
        overlay.set_title("Saved High-class Grad-CAM", fontsize=12, loc="left", pad=9)
        ax2 = fig.add_axes([0.715, y + 0.12, 0.23, 0.17])
        values = [
            case["baseline_probability_high"],
            case["mask_upper_right_pronged_branch_probability_high"],
            case["mask_lower_left_branch_control_probability_high"],
        ]
        ax2.bar([0, 1, 2], values, color=["#687785", "#b65e00", "#007d83"], width=0.6)
        ax2.axhline(0.5, color=COLORS["error"], ls="--", lw=1)
        ax2.set(
            xticks=[0, 1, 2],
            xticklabels=["Original", "Upper-right\nmask", "Lower-left\ncontrol"],
            ylim=(0, 1.15),
            yticks=[0, 0.5, 1],
        )
        ax2.yaxis.set_major_formatter(PercentFormatter(1, decimals=0))
        ax2.tick_params(labelsize=9)
        ax2.set_title("Model probability of High", fontsize=12, loc="left")
        for i, value in enumerate(values):
            ax2.text(i, value + 0.025, f"{value:.2%}", ha="center", fontsize=9)
        gap = 100 * (values[1] - values[2])
        conclusion = (
            "Both edits stay High" if sample == "M93" else "Both edits flip the model to Low"
        )
        fig.text(
            0.715,
            y + 0.05,
            f"Equal area: {case['masked_black_pixels_each']:,} black pixels\nLocation contrast: {gap:+.2f} percentage points\n{conclusion}",
            fontsize=10,
            linespacing=1.5,
            va="top",
            color=COLORS["ink"],
        )
    fig.text(
        0.05,
        0.078,
        "M95: prongs are not a sufficient High signature. Matched edits show location sensitivity, not the actual bandwidth of edited designs.",
        fontsize=10.5,
    )
    fig.text(
        0.05,
        0.056,
        "Brighter = greater positive attribution; each heatmap is scaled separately. Masking scores are saved outputs, not new physical simulations.",
        fontsize=9.5,
        color=COLORS["muted"],
    )
    return fig


def box(fig, xy, width, height, title, body, color):
    x, y = xy
    fig.patches.append(
        Rectangle(
            (x, y),
            width,
            height,
            transform=fig.transFigure,
            facecolor="#f4f7f8",
            edgecolor=COLORS["line"],
            linewidth=1,
        )
    )
    fig.text(
        x + 0.014, y + height - 0.023, title, fontsize=13, weight="bold", color=color, va="top"
    )
    fig.text(
        x + 0.014,
        y + height - 0.063,
        textwrap.fill(body, width=33),
        fontsize=10.5,
        va="top",
        linespacing=1.4,
    )


def roadmap():
    fig = figure(
        "From a visual clue to a physical explanation",
        "Use the image fingerprints to propose a hypothesis, then test model reliance and the optical response separately.",
        4,
    )
    fig.text(
        0.06,
        0.84,
        "AVAILABLE NOW: interpretable evidence",
        fontsize=12,
        weight="bold",
        color=COLORS["Low"],
    )
    boxes = [
        (
            0.06,
            "1. Recognize",
            "Broad black area and a continuous lower arm look High-like. Islands and gaps look Low-like.",
        ),
        (
            0.375,
            "2. Measure",
            "Compare visible descriptors across true classes. Keep training thresholds fixed and show the exceptions.",
        ),
        (
            0.69,
            "3. Probe the model",
            "Use class-specific maps and matched-area masks. A model-score change tests the classifier.",
        ),
    ]
    for x, title, body in boxes:
        box(fig, (x, 0.60), 0.25, 0.20, title, body, COLORS["Low"])
    for x1, x2 in [(0.315, 0.365), (0.63, 0.68)]:
        fig.patches.append(
            FancyArrowPatch(
                (x1, 0.70),
                (x2, 0.70),
                transform=fig.transFigure,
                arrowstyle="-|>",
                mutation_scale=16,
                color=COLORS["muted"],
            )
        )
    fig.text(
        0.06,
        0.535,
        "NEXT PHYSICAL CHECK: establish what changes bandwidth",
        fontsize=12,
        weight="bold",
        color=COLORS["High"],
    )
    boxes = [
        (
            0.06,
            "4. Control the geometry",
            "Verify which pixels mean which material. Change continuity while matching area; include several locations.",
        ),
        (
            0.375,
            "5. Simulate both modes",
            "Compute transmission versus wavelength with the original solver settings. Inspect leakage and scattering.",
        ),
        (
            0.69,
            "6. Recompute bandwidth",
            "Measure each mode's 0.5 dB bandwidth. Reapply the original combined class rule; report tradeoffs.",
        ),
    ]
    for x, title, body in boxes:
        box(fig, (x, 0.29), 0.25, 0.20, title, body, COLORS["High"])
    for x1, x2 in [(0.315, 0.365), (0.63, 0.68)]:
        fig.patches.append(
            FancyArrowPatch(
                (x1, 0.39),
                (x2, 0.39),
                transform=fig.transFigure,
                arrowstyle="-|>",
                mutation_scale=16,
                color=COLORS["muted"],
            )
        )
    fig.text(0.06, 0.22, "Original label definition", fontsize=13, weight="bold")
    fig.text(
        0.06,
        0.178,
        r"$S=BW_0/\langle BW_0\rangle + BW_1/\langle BW_1\rangle$"
        + "     Low: S <= 1.8     High: S >= 2.35     Middle designs excluded",
        fontsize=12,
    )
    fig.text(
        0.06,
        0.13,
        "The source paper supports continuity/gap hypotheses with FDTD examples. That is not a new simulation of M93 or M95.",
        fontsize=10.5,
    )
    fig.text(
        0.06,
        0.095,
        "Primary source: Pira et al., Advancing Photonic Inverse Design with Interpretable Machine Learning (2026).",
        fontsize=10,
    )
    fig.text(
        0.06,
        0.069,
        "https://doi.org/10.1002/adpr.202500284 | Sections 4.1, 5.1-5.2. Local results and methods: README.md and analysis.json.",
        fontsize=9.5,
        color=COLORS["muted"],
    )
    return fig


def main():
    figures = [dictionary(), evidence(), mistakes(), roadmap()]
    names = [
        "01-pattern-dictionary",
        "02-quantitative-evidence",
        "03-error-explanations",
        "04-validation-roadmap",
    ]
    with PdfPages(HERE / "bandwidth-pattern-guide.pdf") as pdf:
        for name, fig in zip(names, figures):
            fig.savefig(HERE / f"{name}.png", dpi=170)
            fig.savefig(HERE / f"{name}.svg")
            pdf.savefig(fig)
            fig.savefig(QA / f"{name}.pdf")
            result = subprocess.run(
                [
                    "sips",
                    "-s",
                    "format",
                    "png",
                    str(QA / f"{name}.pdf"),
                    "--out",
                    str(QA / f"{name}.png"),
                ],
                capture_output=True,
                text=True,
            )
            assert result.returncode == 0, result.stderr
            plt.close(fig)
    sources = [
        PROJECT / "data/common_split_manifest.csv",
        PROJECT
        / "original_bandwidth_explainability_lab/reference/dinov2/best_accuracy_predictions.csv",
        LATEST / "structural_mask_checks.json",
        LATEST / "xai_cases.json",
    ]
    (HERE / "sources.json").write_text(
        json.dumps(
            {
                "analysis_date": "2026-10-26",
                "original_paper": "https://doi.org/10.1002/adpr.202500284",
                "paper_sections": "4.1 (labels), 5.1-5.2 (continuity/gaps and FDTD evidence)",
                "local_sources_sha256": {
                    str(p.relative_to(RESEARCH)): hashlib.sha256(p.read_bytes()).hexdigest()
                    for p in sources
                },
                "notes": "Analysis concerns original Low/High bandwidth labels; it does not combine the SUTD/RDN target. No neural weights or saved outputs were changed.",
            },
            indent=2,
        )
        + "\n"
    )
    print(
        "Rendered four illustrated pages, a combined PDF, editable SVGs and PNGs; PDF pages rendered with sips for QA."
    )


if __name__ == "__main__":
    main()
