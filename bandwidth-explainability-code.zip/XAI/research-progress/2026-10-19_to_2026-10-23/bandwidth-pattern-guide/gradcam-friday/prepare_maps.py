"""Audit four frozen DINOv2 explanations and export their numerical heatmaps."""

import hashlib
import json
from pathlib import Path
import sys

import matplotlib
matplotlib.use("Agg")
from matplotlib import colormaps
import numpy as np
from PIL import Image
import torch

HERE = Path(__file__).resolve().parent
ATLAS = HERE.parent / "expanded-cases"
ROOT = next(p for p in HERE.parents if (p / "model-training").is_dir())
LAB = ROOT / "model-training/original-bandwidth-replication/undated/local-work/original_bandwidth_explainability_lab"
WORKFLOW = ROOT / "model-training/rdn-pretrained-finetuning/2026-10-16_to_2026-10-19/local-work/gradcam_xai"
sys.path[:0] = [str(LAB), str(WORKFLOW)]
from xai_code.models import build_model, Predictor
from workflow import gradcam, target_layer, resize_map, state_hash, sha256

SAMPLES = ["M136", "M11", "M93", "M95"]


def main():
    assets = HERE / "assets"
    assets.mkdir(parents=True, exist_ok=True)
    torch.set_num_threads(4)
    model = build_model(LAB, "dinov2", "cpu")
    predictor = Predictor(model, "dinov2", "cpu", batch_size=1)
    layer, layer_name, layout, grid = target_layer(model, "dinov2")
    before = state_hash(model)
    checkpoint = LAB / "checkpoints/dinov2_best_accuracy.pth"
    checkpoint_before = sha256(checkpoint)
    audit = []
    for sample in SAMPLES:
        prior = json.loads((ATLAS / "data" / sample / "case.json").read_text())
        source = ROOT / prior["source_image"]
        assert sha256(source) == prior["input_image_sha256"]
        assert checkpoint_before == prior["checkpoint_sha256"]
        gray = np.asarray(Image.open(source).convert("L"))
        rgb = np.repeat(gray[..., None], 3, axis=2)
        fresh = gradcam(model, layer, predictor.tensor(rgb)[None], layout, grid)
        saved = np.load(ATLAS / "data" / sample / "maps-and-masks.npz")
        prob_difference = abs(float(fresh["probabilities"][1]) - prior["probability_high"])
        assert prob_difference < 0.0005
        map_errors = {}
        base = rgb / 255.0
        Image.fromarray(rgb).save(assets / f"{sample}-original.png")
        for label, name in [(0, "low"), (1, "high")]:
            native = fresh["maps"][label]["signed_native"]
            error = float(np.max(np.abs(native - saved[name + "_signed_native"])))
            np.testing.assert_allclose(native, saved[name + "_signed_native"], atol=1e-6, rtol=1e-4)
            map_errors[name] = error
            heat = resize_map(fresh["maps"][label]["normalized_native"], gray.shape)
            assert np.isfinite(heat).all() and heat.min() >= 0 and heat.max() <= 1.000001
            alpha = 0.72 * heat[..., None]
            overlay = base * (1 - alpha) + colormaps["inferno"](heat)[..., :3] * alpha
            Image.fromarray(np.rint(255 * overlay).astype(np.uint8)).save(assets / f"{sample}-{name}.png")
        signed_native = fresh["maps"][1]["signed_native"] - fresh["maps"][0]["signed_native"]
        np.testing.assert_allclose(signed_native, saved["contrastive_signed_native"], atol=1e-6, rtol=1e-4)
        signed = resize_map(signed_native, gray.shape)
        scale = float(np.abs(signed_native).max())
        color = colormaps["RdBu_r"](0.5 + signed / (2 * scale))[..., :3]
        alpha = (0.72 * np.abs(signed) / scale)[..., None]
        Image.fromarray(np.rint(255 * (base * (1 - alpha) + color * alpha)).astype(np.uint8)).save(assets / f"{sample}-signed.png")
        audit.append({
            "sample": sample,
            "true_label": prior["true_label"],
            "probability_high": float(fresh["probabilities"][1]),
            "logits_low_high": fresh["logits"].tolist(),
            "logit_margin_high_minus_low": float(fresh["logits"][1] - fresh["logits"][0]),
            "max_prior_probability_difference": prob_difference,
            "max_prior_signed_map_difference": map_errors,
            "hook_max_logit_difference": fresh["hook_max_logit_difference"],
            "source_image": str(source),
            "source_image_sha256": sha256(source),
            "source_arrays_sha256": sha256(ATLAS / "data" / sample / "maps-and-masks.npz"),
        })
        print(sample, "audited", flush=True)
    assert state_hash(model) == before
    assert sha256(checkpoint) == checkpoint_before
    assert not layer._forward_hooks
    assert all(not p.requires_grad and p.grad is None for p in model.parameters())
    # Numerical color bars use the same colormaps as the scientific overlays.
    gradient = np.tile(np.linspace(0, 1, 512), (20, 1))
    for name, cmap in [("positive-legend", "inferno"), ("signed-legend", "RdBu_r")]:
        Image.fromarray(np.rint(255 * colormaps[cmap](gradient)[..., :3]).astype(np.uint8)).save(assets / f"{name}.png")
    report = {
        "model": "DINOv2 vit_small_patch14_dinov2.lvd142m, trained two-class checkpoint",
        "checkpoint_sha256": checkpoint_before,
        "model_state_sha256": before,
        "model_state_unchanged": True,
        "target_layer": layer_name,
        "native_grid": grid,
        "input_size": [224, 224],
        "preprocessing": "Grayscale to RGB, torchvision resize to 224x224, ToTensor, ImageNet mean/std normalization",
        "class_map": "ReLU of gradient-weighted patch activations, normalized to its own positive peak, then bilinearly enlarged",
        "overlay": "inferno color, opacity = 0.72 * independently normalized positive CAM",
        "new_training": False,
        "new_physical_simulation": False,
        "new_attribution_cases": len(audit),
        "new_mask_probes": 0,
        "mask_data": "Reused 27 October atlas probes. A/B/C were chosen by visible geometry, not ranked by Grad-CAM.",
        "source_code_sha256": {str(p): sha256(p) for p in [Path(__file__), LAB / "xai_code/models.py", WORKFLOW / "workflow.py"]},
        "cases": audit,
        "assets_sha256": {p.name: sha256(p) for p in sorted(assets.glob("*.png"))},
    }
    (HERE / "verification.json").write_text(json.dumps(report, indent=2) + "\n")


if __name__ == "__main__":
    main()
