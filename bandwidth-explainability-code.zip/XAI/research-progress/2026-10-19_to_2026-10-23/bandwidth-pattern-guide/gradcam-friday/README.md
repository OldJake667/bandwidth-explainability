# Grad-CAM presentation for Friday

Open [the final presentation](<presentation 26 - 30.10.26.pdf>). Pages 1-9 cover the worked cases and their comparison. Pages 10-11 provide supplementary material.

The main sequence starts with M136 (confident correct High), followed by M11 (borderline correct High), M93 (confident false High), and M95 (weak false High). Each case has a prediction page showing the original image beside large High and Low Grad-CAM maps, with identical A/B/C boxes. Its worked page shows enlarged structural crops and matching original High-CAM crops for all three regions, the exact mask contours, probabilities after each mask, and changes in the class-score margin. The final main page compares M136 and M93.

The worked revision uses the labels **Mask A, Mask B and Mask C** throughout. C is an upper-left structural edit that serves as a reference and can influence the prediction. Colored component crops follow the original atlas's eight-neighbor connectivity and outer-frame exclusion. Magenta contours show the exact saved 4,096-black-pixel deletion within each region. A complete box or complete feature is not necessarily removed. Component colors identify pieces, without physical or class meaning.

All full-image heatmap assets retain their verified checksums. The regional High-CAM views crop those images without separate normalization, preserving comparability between A/B/C within a case. They explain the original image, not the edited images, and enlarging them adds no spatial attribution resolution. Crop definitions, exact native bounds and checks for all 12 masks are in `regions-verification.json`. Arrow tips identify discussed regions rather than measured feature boundaries. The M136/M93 comparison uses independently scaled maps, so it compares locations rather than absolute intensity. This revision needed no additional model inference or physical experiments.

Both class maps were freshly recomputed using the original frozen DINOv2 checkpoint and original preprocessing on CPU. Their signed numerical arrays match the archived case maps within the asserted tolerance. Input-image checksums, checkpoint checksums, model-state checks, exact values and numerical differences are in `verification.json`. No weights changed, no training or physical simulation ran, and no new deletion probes ran.

The overlays show positive Grad-CAM only, with each class map independently normalized to its positive peak. The underlying 16 x 16 patch grid is enlarged by bilinear interpolation. Color intensity is relative local attribution, not an absolute comparison between class scores or a calibrated bandwidth probability. The positive Low maps frequently emphasize frame/background regions. That observation is a candidate image-cue issue, not a demonstrated causal mechanism.

The A/B/C experiments reuse the atlas's 4,096-black-pixel protocol. A/B/C were geometry-based choices, not Grad-CAM-ranked selections. The separate signed-map appendix subtracts signed class maps before ReLU or normalization. The original atlas and source outputs remain unchanged.

## Reproduction

From this repository, use the existing original-bandwidth project environment for the numerical analysis:

```sh
MPLCONFIGDIR=/tmp/gradcam-friday-mpl /Users/olzh/Documents/research/model-training/original-bandwidth-replication/undated/local-work/.venv/bin/python -B gradcam-friday/prepare_maps.py
MPLCONFIGDIR=/tmp/gradcam-friday-mpl /Users/olzh/Documents/research/model-training/original-bandwidth-replication/undated/local-work/.venv/bin/python -B gradcam-friday/prepare_regions.py
python3 gradcam-friday/build_deck.py
```

The PDF builder produces the 14-page version with introductions using the system's existing ReportLab and PyMuPDF packages and macOS Arial font files. It renders the deck to `.review/` and checks page count, dimensions, labels, exact mask scores, asset checksums and text containment. The 12-page case-only export removes the first two pages and replaces footer numbers, with its provenance in `case-deck-verification.json`. All 12 scientific page bodies render identically to their source pages above the footer. No dependency was added. PDF text remains selectable. An editable PowerPoint version is not included because the prescribed presentation authoring runtime was unavailable.
