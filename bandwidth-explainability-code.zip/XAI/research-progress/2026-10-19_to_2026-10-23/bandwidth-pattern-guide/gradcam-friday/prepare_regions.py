"""Render exact saved A/B/C crops and masks beside unchanged High-CAM crops."""

import hashlib
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image
from scipy import ndimage

HERE = Path(__file__).resolve().parent
ATLAS = HERE.parent / "expanded-cases"
SAMPLES = ["M136", "M11", "M93", "M95"]
MASK_COLOR = "#c00069"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    audit = json.loads((HERE / "verification.json").read_text())
    originals = {r["sample"]: r for r in audit["cases"]}
    control = json.loads((ATLAS / "results.json").read_text())["control_roi"]
    output = HERE / "assets/regions"
    output.mkdir(exist_ok=True)
    records = []
    for sample in SAMPLES:
        record = json.loads((ATLAS / "data" / sample / "case.json").read_text())
        source = Path(originals[sample]["source_image"])
        arrays_path = ATLAS / "data" / sample / "maps-and-masks.npz"
        assert digest(source) == record["input_image_sha256"]
        assert digest(arrays_path) == originals[sample]["source_arrays_sha256"]
        gray = np.asarray(Image.open(source).convert("L"))
        high_path = HERE / f"assets/{sample}-high.png"
        assert digest(high_path) == audit["assets_sha256"][high_path.name]
        high = np.asarray(Image.open(high_path).convert("RGB"))
        arrays = np.load(arrays_path)
        black = gray < 128
        # Match the original atlas: omit the rendered outer frame for components.
        black[:8] = black[-8:] = False
        black[:, :8] = black[:, -8:] = False
        components, _ = ndimage.label(black, structure=np.ones((3, 3)))
        means = []
        for label, roi in [("A", record["a"]), ("B", record["b"]), ("C", control)]:
            height, width = gray.shape
            x0, y0, x1, y1 = [int(v * (width if i % 2 == 0 else height)) for i, v in enumerate(roi)]
            mask = arrays[f"mask_{label}"]
            assert int(mask.sum()) == 4096 and np.all(gray[mask] == 0)
            local_mask = mask[y0:y1, x0:x1]
            assert int(local_mask.sum()) == 4096
            native = gray[y0:y1, x0:x1]
            colored = np.repeat((native / 255.0)[..., None], 3, axis=2)
            local = components[y0:y1, x0:x1]
            sizes = np.bincount(local.ravel())
            ids = sorted((i for i in range(1, len(sizes)) if sizes[i] >= 100), key=lambda i: sizes[i], reverse=True)
            for rank, component in enumerate(ids[:8]):
                colored[local == component] = plt.get_cmap("tab10")(rank)[:3]
            for kind, pixels in [("structure", colored), ("high", high[y0:y1, x0:x1])]:
                fig = plt.figure(figsize=((x1-x0)/100, (y1-y0)/100), dpi=150, facecolor="white")
                ax = fig.add_axes([0, 0, 1, 1])
                ax.imshow(pixels, interpolation="nearest")
                ax.contour(local_mask, levels=[.5], colors=[MASK_COLOR], linewidths=1.4)
                if kind == "structure" and len(ids) >= 2:
                    distance, nearest = ndimage.distance_transform_edt(local != ids[1], return_indices=True)
                    yy, xx = np.unravel_index(np.argmin(np.where(local == ids[0], distance, np.inf)), local.shape)
                    yy2, xx2 = nearest[:, yy, xx]
                    ax.annotate("", (xx2, yy2), (xx, yy), arrowprops={"arrowstyle": "<->", "color": "#252525", "lw": 1})
                    ax.text((xx+xx2)/2, (yy+yy2)/2-6, "gap", ha="center", fontsize=8,
                            bbox={"facecolor": "white", "edgecolor": "none", "pad": 1})
                ax.set_axis_off()
                path = output / f"{sample}-{label}-{kind}.png"
                fig.savefig(path, dpi=150)
                plt.close(fig)
            edited = gray.copy()
            edited[mask] = 255
            means.append(float(edited.mean()))
            records.append({"sample": sample, "region": label, "roi": roi,
                            "native_bounds_xyxy": [x0, y0, x1, y1],
                            "masked_black_pixels": int(mask.sum()),
                            "crop_native_size": [x1-x0, y1-y0],
                            "high_crop_normalization": "Inherited from full-image High map; no crop normalization",
                            "source_arrays_sha256": digest(arrays_path)})
        assert len(set(means)) == 1
    report = {"regions": records, "mask_count": 12, "all_masks_are_saved_4096_pixel_edits": True,
              "new_inference": False, "new_mask_probes": False,
              "component_colors": "Eight-connected black components, outer eight pixels excluded, matching original atlas",
              "mask_outline_color": MASK_COLOR,
              "source_code_sha256": digest(Path(__file__)),
              "assets_sha256": {p.name: digest(p) for p in sorted(output.glob("*.png"))}}
    (HERE / "regions-verification.json").write_text(json.dumps(report, indent=2)+"\n")
    print("Prepared and verified 12 regions, 24 scientific crops, and exact saved mask contours.")


if __name__ == "__main__":
    main()
