"""Build a Grad-CAM presentation from audited scientific images and editable text."""

import hashlib
import json
import math
from pathlib import Path

import fitz
from reportlab.lib.colors import HexColor
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.pdfgen import canvas

HERE = Path(__file__).resolve().parent
ASSETS = HERE / "assets"
REVIEW = HERE / ".review"
W, H = 960, 540
INK = "#172b3b"
MUTED = "#526373"
TEAL = "#007d83"
RED = "#b32635"
REGION_COLORS = {"A": "#b65e00", "B": "#008366", "C": "#657180"}
REGION_NAMES = {
    "M136": ["Broad lower body", "Upper-right prongs", "Upper-left body"],
    "M11": ["Separated lower lobes", "Upper-right arm", "Upper-left body"],
    "M93": ["Diagonal lower arm", "Upper-right branch", "Upper-left body"],
    "M95": ["Upper-right prongs", "Lower-right islands", "Upper-left body"],
}
WORKED_READINGS = {
    "M136": "A and B overlap positive High attribution. B gives the largest margin drop.\nMask C raises the score slightly. All three edited predictions stay High.",
    "M11": "B overlaps positive High attribution and its deletion flips the prediction to Low.\nA barely changes the score. Mask C raises it. The specific deleted pixels matter.",
    "M93": "All three regions overlap positive High attribution and all three masks lower the score.\nThe prediction stays High after every edit, despite the original true Low label.",
    "M95": "A looks prominent in Grad-CAM, but masks B and C flip the prediction to Low.\nThe larger B response shows a mismatch between local attribution and a finite deletion.",
}

CASES = [
    dict(sample="M136", title="A confident, correct High prediction", truth="High", kind="True positive",
         high="The upper-right arm and broad lower arm carry positive High attribution.",
         low="Positive Low attribution appears mainly near the frame and surrounding white space.",
         reading="The highlighted structures are candidate cues for this correct High prediction."),
    dict(sample="M11", title="A correct High prediction near the boundary", truth="High", kind="True positive",
         high="The upper-right arm and both broad lower pieces carry positive High attribution.",
         low="Positive Low attribution appears near the top and bottom edges and in white gaps.",
         reading="The score is only 50.44% High. Strong map colors do not imply a confident prediction."),
    dict(sample="M93", title="A confident High prediction on a Low design", truth="Low", kind="False positive",
         high="The lower-right diagonal arm, upper-right branch and left-side pieces are highlighted.",
         low="Positive Low attribution appears mainly near the lower edge and other white regions.",
         reading="These are candidate cues for the wrong High score. The physical label remains Low."),
    dict(sample="M95", title="A weak High prediction on a Low design", truth="Low", kind="False positive",
         high="The upper-right arm, upper-left body and lower-left strip carry positive High attribution.",
         low="Positive Low attribution appears along the frame and in surrounding white regions.",
         reading="Attribution is distributed. The upper-right prongs alone do not explain the error."),
]

# Positions identify discussed regions on coarse maps, not measured feature boundaries.
# Coordinates are fractions of the displayed image, with y measured from its top.
HIGH_LABELS = {
    "M136": [
        ("Upper-right arm", (.64, .41), (.86, .29)),
        ("Broad lower arm", (.30, .59), (.73, .75)),
    ],
    "M11": [
        ("Upper-right arm", (.65, .43), (.80, .30)),
        ("Lower-left piece", (.28, .73), (.30, .88)),
        ("Lower-right piece", (.68, .60), (.80, .76)),
    ],
    "M93": [
        ("Upper-right branch", (.65, .43), (.79, .30)),
        ("Diagonal lower arm", (.64, .61), (.72, .76)),
        ("Left-side pieces", (.26, .64), (.36, .48)),
    ],
    "M95": [
        ("Upper-right arm", (.70, .43), (.81, .29)),
        ("Upper-left body", (.27, .23), (.25, .12)),
        ("Lower-left strip", (.31, .73), (.30, .88)),
    ],
}
LOW_LABELS = [
    ("White space near frame", (.50, .24), (.92, .04)),
    ("Lower edge / white space", (.46, .77), (.90, .96)),
]


def text(c, x, y, value, size=17, color=INK, bold=False, width=None, leading=None):
    font = "ArialBold" if bold else "Arial"
    c.setFont(font, size)
    c.setFillColor(HexColor(color))
    lines = []
    for paragraph in value.split("\n"):
        current = ""
        for word in paragraph.split():
            candidate = (current + " " + word).strip()
            if width and pdfmetrics.stringWidth(candidate, font, size) > width:
                lines.append(current)
                current = word
            else:
                current = candidate
        lines.append(current)
    step = leading or size * 1.27
    for i, line in enumerate(lines):
        assert not width or pdfmetrics.stringWidth(line, font, size) <= width + 1
        baseline = y - i * step
        assert baseline >= 15, (value, baseline)
        c.drawString(x, baseline, line)
    return y - len(lines) * step


def image(c, name, x, y, w, h):
    c.drawImage(str(ASSETS / name), x, y, width=w, height=h, preserveAspectRatio=True, anchor="c", mask="auto")


def region_boxes(c, record, control_roi, x, y, w, h):
    c.saveState()
    for label, roi in [("A", record["a"]), ("B", record["b"]), ("C", control_roi)]:
        x0, y0, x1, y1 = roi
        left, bottom = x+w*x0, y+h*(1-y1)
        c.setStrokeColor(HexColor("#ffffff"))
        c.setLineWidth(3)
        c.rect(left, bottom, w*(x1-x0), h*(y1-y0), fill=0)
        c.setStrokeColor(HexColor(REGION_COLORS[label]))
        c.setLineWidth(1.4)
        c.rect(left, bottom, w*(x1-x0), h*(y1-y0), fill=0)
        c.setFillColor(HexColor("#ffffff"))
        c.rect(left+1, y+h*(1-y0)-15, 14, 14, stroke=0, fill=1)
        text(c, left+3, y+h*(1-y0)-12, label, 12, REGION_COLORS[label], True)
    c.restoreState()


def annotated_map(c, sample, kind, x, y, w, h, atlas_record=None, control_roi=None):
    image(c, f"{sample}-{kind}.png", x, y, w, h)
    if atlas_record is not None:
        region_boxes(c, atlas_record, control_roi, x, y, w, h)
    labels = HIGH_LABELS[sample] if kind == "high" else LOW_LABELS
    c.saveState()
    for label, position, target in labels:
        cx, cy = x + w*position[0], y + h*(1-position[1])
        tx, ty = x + w*target[0], y + h*(1-target[1])
        box_w = pdfmetrics.stringWidth(label, "ArialBold", 9.5) + 10
        box_h = 16
        left, bottom = cx-box_w/2, cy-box_h/2
        assert x <= left and left+box_w <= x+w
        assert y <= bottom and bottom+box_h <= y+h
        # Stop the leader at the label boundary so it cannot cross the text.
        dx, dy = tx-cx, ty-cy
        edge = min((box_w/2)/abs(dx) if dx else float("inf"),
                   (box_h/2)/abs(dy) if dy else float("inf"))
        assert edge < 1, label
        sx, sy = cx + edge*dx, cy + edge*dy
        c.setStrokeColor(HexColor("#ffffff"))
        c.setLineWidth(2.6)
        c.line(sx, sy, tx, ty)
        c.setStrokeColor(HexColor(TEAL))
        c.setLineWidth(1.1)
        c.line(sx, sy, tx, ty)
        angle = math.atan2(dy, dx)
        for side in (-1, 1):
            c.line(tx, ty, tx-5*math.cos(angle+side*.5), ty-5*math.sin(angle+side*.5))
        c.setFillColor(HexColor("#ffffff"))
        c.rect(left, bottom, box_w, box_h, stroke=0, fill=1)
        text(c, left+5, cy-3.4, label, 9.5, TEAL, bold=True)
    c.restoreState()


def page(c, title, number, subtitle=None, appendix=False):
    text(c, 42, 497, title, 28, bold=True, width=876)
    if subtitle:
        text(c, 42, 468, subtitle, 15, MUTED, width=876)
    text(c, 42, 21, "DINOv2 bandwidth classifier    " + ("Appendix" if appendix else "Friday discussion"), 10, MUTED)
    text(c, 899, 21, str(number), 10, MUTED)


def case_page(c, spec, record, number, atlas_record, control_roi):
    p = record["probability_high"]
    margin = record["logit_margin_high_minus_low"]
    page(c, f'{spec["sample"]}: {spec["title"]}', number,
         f'True {spec["truth"]}     Predicted High     P(High) {100*p:.2f}%     P(Low) {100*(1-p):.2f}%     {spec["kind"]}')
    for x, name, label in [(42, "original", "Original image"), (348, "high", "Grad-CAM for the High score"), (654, "low", "Grad-CAM for the Low score")]:
        text(c, x, 447, label, 15, bold=True)
        if name == "original":
            image(c, f'{spec["sample"]}-{name}.png', x, 178, 264, 260.57)
            region_boxes(c, atlas_record, control_roi, x, 178, 264, 260.57)
        else:
            annotated_map(c, spec["sample"], name, x, 178, 264, 260.57, atlas_record, control_roi)
    image(c, "positive-legend.png", 348, 160, 160, 7)
    text(c, 516, 158, "Relative positive attribution. Boxes identify A/B/C.", 10, MUTED)
    text(c, 42, 136, "High map: " + spec["high"], 15, width=876, leading=19)
    text(c, 42, 113, "Low map: " + spec["low"], 15, width=876, leading=19)
    text(c, 42, 90, spec["reading"], 15, RED if spec["truth"] == "Low" else TEAL, True, width=876, leading=19)
    text(c, 42, 52, "Each class map uses its own scale. Colors cannot be compared as absolute class evidence.", 11, MUTED)
    text(c, 42, 37, f'Positive attribution only. Enlarged 16 x 16 patch map. High-minus-Low logit margin: {margin:+.3f}.', 10, MUTED)
    c.showPage()


def methods(c):
    page(c, "Grad-CAM connection to the classifier", 1,
         "The same saved DINOv2 classifier produces both the prediction and the attribution maps")
    steps = [
        ("1  Image and saved classifier", "Resize the image to 224 x 224, apply the original normalization, then run the frozen model."),
        ("2  Class scores", "The classifier outputs Low and High logits. Softmax converts these scores to P(Low) and P(High)."),
        ("3  Gradients and patch activations", "For each class, differentiate its logit at blocks.11.norm1, before the final attention operation."),
        ("4  Displayed class maps", "Average gradients over patches, weight the activations, sum channels, then keep positive values."),
    ]
    y = 422
    for heading, explanation in steps:
        text(c, 42, y, heading, 18, bold=True)
        text(c, 42, y-25, explanation, 16, width=876, leading=20)
        y -= 78
    text(c, 42, 106, "Reading the maps", 18, bold=True)
    text(c, 42, 79, "Bright regions have larger relative positive attribution to the named class score.", 16, width=876)
    text(c, 42, 56, "Each map has its own scale. A 16 x 16 map gives coarse localization, not pixel detail.", 16, width=876)
    text(c, 42, 37, "Arrows label discussed regions. They are visual annotations, not automatic feature selections.", 11, MUTED)
    c.showPage()


def worked_page(c, spec, record, number):
    sample = spec["sample"]
    page(c, f"{sample}: A/B/C crops and masking results", number,
         f'Original P(High) {100*record["probability_high"]:.2f}%. Each mask separately whitens exactly 4,096 black pixels.')
    for i, probe in enumerate(record["probes"]):
        label = probe["region"]
        assert label == "ABC"[i]
        x = 42 + i*306
        text(c, x, 440, f"Mask {label}: {REGION_NAMES[sample][i]}", 16, REGION_COLORS[label], True, width=264)
        text(c, x, 418, "Structure and exact mask outline", 12, MUTED)
        image(c, f"regions/{sample}-{label}-structure.png", x, 285, 264, 125)
        text(c, x, 270, "Original High-class Grad-CAM, same crop", 12, MUTED)
        image(c, f"regions/{sample}-{label}-high.png", x, 137, 264, 125)
        prediction = "High" if probe["predicted_label"] else "Low"
        text(c, x, 116, f'After mask {label}: {100*probe["probability_high"]:.2f}% High', 15, bold=True)
        text(c, x, 97, f'Predicted {prediction}. Margin change {probe["delta_margin"]:+.3f}.', 12, MUTED)
    text(c, 42, 74, WORKED_READINGS[sample], 14, TEAL if spec["truth"] == "High" else RED, True, width=876, leading=18)
    text(c, 42, 37, "Component colors distinguish pieces. Magenta outlines show exact deletions. CAM crops retain the full-image scale.", 10, MUTED)
    c.showPage()


def regions_introduction(c):
    page(c, "Reading the A/B/C worked examples", 2,
         "The region labels connect the image, Grad-CAM evidence and a separate masking check")
    sections = [
        ("A/B/C on the prediction pages", "The same boxes mark the original image and both class maps. Each box defines a region to inspect."),
        ("Enlarged structural crops", "Colors distinguish connected black pieces. Magenta contours mark the exact pixels removed by each mask."),
        ("Matching Grad-CAM crops", "The second row shows the original image's High map in the same region. Crops keep its full-image scale."),
        ("Masks A, B and C", "Each edit separately whitens 4,096 black pixels. Mask C covers upper-left structure and serves as a reference."),
    ]
    for i, (heading, body) in enumerate(sections):
        y = 422-i*79
        text(c, 42, y, heading, 19, bold=True)
        text(c, 42, y-26, body, 16, width=876, leading=21)
    text(c, 42, 89, "The boxes were chosen from geometry, independently of Grad-CAM ranking.", 16, bold=True, width=876)
    text(c, 42, 63, "An edit can disagree with a local heatmap. C contains real structure and can affect the score.", 15, width=876)
    text(c, 42, 40, "A whole box or feature is not necessarily removed. Masking tests the classifier, with no new physical simulation.", 12, MUTED, width=876)
    c.showPage()


def comparison_page(c, records):
    page(c, "Similar High attribution, different true labels", 11,
         "DINOv2 High-class Grad-CAM for a correct prediction and an error")
    for sample, x, heading in [("M136", 102, "M136: correct High"), ("M93", 578, "M93: incorrect High")]:
        r = records[sample]
        truth = "High" if r["true_label"] else "Low"
        text(c, x-14, 438, heading, 21, TEAL if truth == "High" else RED, True)
        text(c, x-14, 414, f'True {truth}. Predicted High, {100*r["probability_high"]:.2f}%.', 15)
        annotated_map(c, sample, "high", x, 119, 280, 276.36)
    text(c, 42, 94, "Both maps highlight upper-right and lower structures. This suggests shared spatial cues", 17, width=876)
    text(c, 42, 71, "for the High scores, although M93 is truly Low. These cues do not establish bandwidth.", 17, width=876)
    text(c, 42, 43, "Same checkpoint, target class and layer. Independent scales: compare locations, not color brightness.", 12, MUTED, width=876)
    c.showPage()


def signed_page(c):
    page(c, "Signed High-minus-Low attribution", 12,
         "An additional local comparison, computed before ReLU and before normalization", appendix=True)
    for i, sample in enumerate(["M136", "M11", "M93", "M95"]):
        x = 42 + i*225
        text(c, x, 420, sample, 18, bold=True)
        image(c, f"{sample}-signed.png", x, 190, 201, 198.4)
    image(c, "signed-legend.png", 315, 161, 330, 9)
    text(c, 315, 141, "Toward Low", 13, MUTED)
    text(c, 463, 141, "0", 13, MUTED)
    text(c, 568, 141, "Toward High", 13, MUTED)
    text(c, 42, 108, "Signed map = signed CAM(High) - signed CAM(Low). Each image has its own scale.", 16, width=876)
    text(c, 42, 78, "This coarse local approximation does not decompose or fully explain the final score.", 16, width=876)
    text(c, 42, 49, "A dark black structure may hide a weak overlay. Pale regions indicate little local attribution.", 13, MUTED, width=876)
    c.showPage()


def masking_page(c, atlas):
    page(c, "Deletion tests provide supporting evidence", 13,
         "Saved 27 October results. A/B/C were chosen from geometry, independently of Grad-CAM ranking", appendix=True)
    xs = [42, 194, 348, 498, 648]
    for x, label in zip(xs, ["Image", "Original", "Mask A", "Mask B", "Mask C"]):
        text(c, x, 418, label, 16, bold=True)
    for i, sample in enumerate(["M136", "M11", "M93", "M95"]):
        r = atlas[sample]
        values = [sample, f'{100*r["probability_high"]:.2f}%'] + [f'{100*q["probability_high"]:.2f}%' for q in r["probes"]]
        for x, value in zip(xs, values):
            text(c, x, 381-i*34, value, 17)
    text(c, 42, 244, "Every edit whitens 4,096 black pixels. The table reports P(High).", 16, bold=True, width=876)
    definitions = [
        "M136: A lower body. B upper-right prongs. C upper-left structure.",
        "M11: A lower-right lobe. B upper-right arm. C upper-left structure.",
        "M93: A lower-right arm. B upper-right branch. C upper-left structure.",
        "M95: A upper-right prongs. B lower-right islands. C upper-left structure.",
    ]
    for i, line in enumerate(definitions):
        text(c, 42, 210-i*24, line, 15, width=876)
    text(c, 42, 95, "M95 shows a mismatch: A looks prominent in Grad-CAM, but B produces a larger score drop.", 16, bold=True, width=876)
    text(c, 42, 65, "Local gradients and finite deletions measure different sensitivities. C also contains structure.", 15, width=876)
    text(c, 42, 42, "Edited devices have no simulated physical bandwidth labels. Native brightness matches exactly within each case.", 11, MUTED, width=876)
    c.showPage()


def sources_page(c):
    page(c, "Scope and sources", 14, "Four inspected validation cases explain individual model outputs", appendix=True)
    text(c, 42, 419, "Evidence used", 19, bold=True)
    text(c, 42, 389, "Original dataset: 221 images, with 176 training and 45 validation images.\nAll four examples use the original DINOv2 checkpoint and preprocessing.\nFresh CPU gradients reproduce the saved maps and predictions.\nThe analysis leaves the checkpoint and model weights unchanged.", 17, width=876, leading=29)
    text(c, 42, 257, "Interpretation limits", 19, bold=True)
    text(c, 42, 227, "Separate positive class maps omit negative contributions.\nBright Low attribution near the frame or white space raises a possible image-cue issue.\nGrad-CAM does not establish an optical mechanism or measure physical bandwidth.\nThese selected cases do not provide a fresh estimate of generalization accuracy.", 16, width=876, leading=27)
    text(c, 42, 103, "Grad-CAM: Selvaraju et al.   https://arxiv.org/abs/1610.02391", 13, MUTED, width=876)
    c.linkURL("https://arxiv.org/abs/1610.02391", (42, 99, 650, 118), relative=0)
    text(c, 42, 81, "Photonic dataset paper: https://doi.org/10.1002/adpr.202500284", 13, MUTED, width=876)
    c.linkURL("https://doi.org/10.1002/adpr.202500284", (42, 77, 650, 96), relative=0)
    text(c, 42, 51, "Local records: expanded-cases/results.json, data/<image>/maps-and-masks.npz and verification.json", 10, MUTED, width=876)
    c.showPage()


def main():
    REVIEW.mkdir(exist_ok=True)
    fonts = Path("/System/Library/Fonts/Supplemental")
    pdfmetrics.registerFont(TTFont("Arial", str(fonts / "Arial.ttf")))
    pdfmetrics.registerFont(TTFont("ArialBold", str(fonts / "Arial Bold.ttf")))
    audit = json.loads((HERE / "verification.json").read_text())
    records = {r["sample"]: r for r in audit["cases"]}
    atlas_report = json.loads((HERE.parent / "expanded-cases/results.json").read_text())
    atlas = {r["sample"]: r for r in atlas_report["cases"]}
    regions = json.loads((HERE / "regions-verification.json").read_text())
    out = HERE / "gradcam-prediction-explanations-worked.pdf"
    c = canvas.Canvas(str(out), pagesize=(W, H), pageCompression=1)
    c.setTitle("Grad-CAM explanations of DINOv2 bandwidth predictions")
    c.setAuthor("Bandwidth explainability research")
    methods(c)
    regions_introduction(c)
    for index, spec in enumerate(CASES):
        number = 3+2*index
        case_page(c, spec, records[spec["sample"]], number, atlas[spec["sample"]], atlas_report["control_roi"])
        worked_page(c, spec, atlas[spec["sample"]], number+1)
    comparison_page(c, records)
    signed_page(c)
    masking_page(c, atlas)
    sources_page(c)
    c.save()
    pdf = fitz.open(out)
    assert len(pdf) == 14
    for i, page_ in enumerate(pdf):
        assert abs(page_.rect.width-W) < .1 and abs(page_.rect.height-H) < .1
        for block in page_.get_text("dict")["blocks"]:
            if "lines" not in block:
                continue
            for line in block["lines"]:
                for span in line["spans"]:
                    box = fitz.Rect(span["bbox"])
                    assert box.x0 >= 0 and box.y0 >= 0 and box.x1 <= W and box.y1 <= H, span
        page_.get_pixmap(matrix=fitz.Matrix(1.5, 1.5)).save(REVIEW / f"slide-{i+1:02}.png")
    expected = ["Grad-CAM connection", "Reading the A/B/C", "M136:", "M136: A/B/C", "M11:", "M11: A/B/C", "M93:", "M93: A/B/C", "M95:", "M95: A/B/C", "Similar High attribution", "Signed High-minus-Low", "Deletion tests", "Scope and sources"]
    for i, phrase in enumerate(expected):
        assert phrase in pdf[i].get_text()
    for i, sample in enumerate(["M136", "M11", "M93", "M95"]):
        content = pdf[2+2*i].get_text()
        for label, _, _ in HIGH_LABELS[sample] + LOW_LABELS:
            assert label in content, (sample, label)
        assert f'{100*records[sample]["probability_high"]:.2f}%' in content
        detail = pdf[3+2*i].get_text()
        for label in "ABC":
            assert f"Mask {label}:" in detail and f"After mask {label}:" in detail
        for probe in atlas[sample]["probes"]:
            assert f'{100*probe["probability_high"]:.2f}% High' in detail
    assert "Comparison C" not in "\n".join(p.get_text() for p in pdf)
    comparison = pdf[10].get_text()
    for phrase in ["True High", "True Low", "99.97%", "94.46%", "Independent scales"]:
        assert phrase in comparison
    for name, digest in audit["assets_sha256"].items():
        assert hashlib.sha256((ASSETS / name).read_bytes()).hexdigest() == digest
    for name, digest in regions["assets_sha256"].items():
        assert hashlib.sha256((ASSETS / "regions" / name).read_bytes()).hexdigest() == digest
    audit["presentation"] = {
        "file": out.name,
        "sha256": hashlib.sha256(out.read_bytes()).hexdigest(),
        "pages": len(pdf),
        "main_pages": 11,
        "appendix_pages": 3,
        "all_text_within_page": True,
        "rendered_pages": len(pdf),
        "annotations": "Native PDF labels and arrows added over unchanged heatmap assets",
        "annotation_and_comparison_checks_passed": True,
        "heatmap_assets_unchanged": True,
        "new_inference_for_annotation_revision": False,
        "worked_regions": len(regions["regions"]),
        "region_crops_preserve_global_cam_normalization": True,
        "regions_verification_sha256": hashlib.sha256((HERE / "regions-verification.json").read_bytes()).hexdigest(),
    }
    (HERE / "verification.json").write_text(json.dumps(audit, indent=2) + "\n")
    print(out)


if __name__ == "__main__":
    main()
