"""Small synthetic checks; no model training or physical inference."""

import numpy as np

from analyze_patterns import best_stump, shape_features


def main():
    white = np.full((64, 64), 255, dtype=np.uint8)
    assert shape_features(white)["dark_coverage"] == 0
    assert shape_features(white)["largest_component_fraction"] == 0
    black = np.zeros((64, 64), dtype=np.uint8)
    assert shape_features(black)["dark_coverage"] == 1
    assert shape_features(black)["largest_component_fraction"] == 1

    disconnected = white.copy()
    disconnected[16:24, 16:24] = 0
    disconnected[16:24, 32:40] = 0
    assert shape_features(disconnected)["largest_component_fraction"] == 0.5
    connected = disconnected.copy()
    connected[19:21, 24:32] = 0
    assert shape_features(connected)["largest_component_fraction"] == 1

    values = np.array([0.1, 0.2, 0.7, 0.8])
    labels = np.array([0, 0, 1, 1])
    sign, threshold, correct = best_stump(values, labels)
    assert sign == 1 and abs(threshold - 0.45) < 1e-12 and correct == 4
    sign, threshold, correct = best_stump(values, 1 - labels)
    assert sign == -1 and abs(threshold - 0.45) < 1e-12 and correct == 4
    print("8 synthetic feature and threshold checks passed.")


if __name__ == "__main__":
    main()
