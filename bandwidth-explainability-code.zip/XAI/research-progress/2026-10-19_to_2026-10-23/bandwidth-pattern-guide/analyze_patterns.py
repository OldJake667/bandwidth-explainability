"""Exploratory image descriptors for the original Low/High bandwidth dataset.

Uses the existing split and archived predictions; no neural training or new
physical simulations. Thresholds use training labels only.
"""

import csv
import hashlib
import json
from pathlib import Path

import numpy as np
from PIL import Image
from scipy import ndimage, stats
from sklearn.metrics import confusion_matrix, roc_auc_score

HERE = Path(__file__).resolve().parent
RESEARCH = next(parent for parent in HERE.parents if (parent / "model-training").is_dir())
PROJECT = RESEARCH / "model-training/original-bandwidth-replication/undated/local-work"
LAB = PROJECT / "original_bandwidth_explainability_lab"
MANIFEST = LAB / "reference/original_176_45_split_manifest.csv"


def shape_features(gray):
    assert gray.ndim == 2 and gray.dtype == np.uint8
    height, width = gray.shape
    foreground = gray < 128
    interior = foreground[8:-8, 8:-8]
    components, number = ndimage.label(interior, structure=np.ones((3, 3)))
    sizes = np.bincount(components.ravel())[1:]
    total = max(int(interior.sum()), 1)
    substantial = sizes >= 0.001 * interior.size
    lower = foreground[int(0.55 * height) : int(0.98 * height), 8:-8]
    lower_labels, _ = ndimage.label(lower, structure=np.ones((3, 3)))
    spans = [slc[1].stop - slc[1].start for slc in ndimage.find_objects(lower_labels)]
    return {
        "mean_gray": float(gray.mean()),
        "dark_coverage": float(1 - gray.mean() / 255),
        "black_fraction": float(foreground.mean()),
        "lower_black_fraction": float(lower.mean()),
        "largest_component_fraction": float(sizes.max() / total) if number else 0.0,
        "substantial_components": int(substantial.sum()),
        "small_island_fraction": float(sizes[sizes < 0.005 * interior.size].sum() / total),
        "lower_component_span": max(spans, default=0) / lower.shape[1],
    }


def best_stump(values, labels):
    distinct = np.unique(values)
    thresholds = np.r_[-np.inf, (distinct[:-1] + distinct[1:]) / 2, np.inf]
    choices = []
    for sign in (1, -1):
        for threshold in thresholds:
            predicted = values >= threshold if sign == 1 else values <= threshold
            choices.append((int((predicted == labels).sum()), sign, float(threshold)))
    score, sign, threshold = max(choices, key=lambda choice: choice[0])
    return sign, threshold, score


def main():
    rows = list(csv.DictReader(MANIFEST.open(newline="")))
    assert len(rows) == 221
    prediction_path = LAB / "reference/dinov2/best_accuracy_predictions.csv"
    predictions = {r["file"]: r for r in csv.DictReader(prediction_path.open(newline=""))}
    records = []
    for row in rows:
        label = int(row["label"])
        image = (
            PROJECT / "data" / ("combined_high_bw" if label else "combined_low_bw") / row["file"]
        )
        gray = np.asarray(Image.open(image).convert("L"))
        assert gray.shape == (760, 770)
        record = {**row, **shape_features(gray)}
        record["image_sha256"] = hashlib.sha256(image.read_bytes()).hexdigest()
        record["image_path"] = str(image.relative_to(RESEARCH))
        record["dinov2_probability_high"] = (
            float(predictions[row["file"]]["probability_high"])
            if row["file"] in predictions
            else ""
        )
        records.append(record)
    train = [r for r in records if r["split"] == "train"]
    validation = [r for r in records if r["split"] == "validation"]
    assert len(train) == 176 and len(validation) == 45
    labels_train = np.array([int(r["label"]) for r in train])
    labels_val = np.array([int(r["label"]) for r in validation])
    features = [
        "dark_coverage",
        "lower_black_fraction",
        "largest_component_fraction",
        "substantial_components",
        "small_island_fraction",
        "lower_component_span",
    ]
    summary = {}
    for name in features:
        x_train = np.array([r[name] for r in train])
        x_val = np.array([r[name] for r in validation])
        sign, threshold, correct = best_stump(x_train, labels_train)
        val_pred = (x_val >= threshold if sign == 1 else x_val <= threshold).astype(int)
        summary[name] = {
            "high_if": ">=" if sign == 1 else "<=",
            "threshold": threshold,
            "train_correct": correct,
            "train_total": len(train),
            "validation_correct": int((val_pred == labels_val).sum()),
            "validation_total": len(validation),
            "validation_confusion_matrix_low_high": confusion_matrix(labels_val, val_pred).tolist(),
            "training_auc_oriented": float(roc_auc_score(labels_train, sign * x_train)),
            "validation_auc_oriented": float(roc_auc_score(labels_val, sign * x_val)),
            "training_class_means": {
                str(label): float(x_train[labels_train == label].mean()) for label in (0, 1)
            },
            "validation_errors": [
                r["file"] for r, p in zip(validation, val_pred) if p != int(r["label"])
            ],
        }
    brightness = summary["dark_coverage"]
    equivalent_gray = 255 * (1 - brightness["threshold"])
    assert abs(equivalent_gray - 202.30406698564593) < 1e-9
    assert brightness["train_correct"] == 170 and brightness["validation_correct"] == 43
    representatives = {}
    for label in (0, 1):
        median = float(np.median([r["dark_coverage"] for r in train if int(r["label"]) == label]))
        candidate = min(
            (r for r in validation if int(r["label"]) == label),
            key=lambda r: abs(r["dark_coverage"] - median),
        )
        representatives["Low" if label == 0 else "High"] = candidate["file"]
    spearman = stats.spearmanr(
        [r["dark_coverage"] for r in validation], [r["dinov2_probability_high"] for r in validation]
    )
    diagnostic = {
        "scope": "Original 221-image bandwidth labels; not the SUTD/RDN peak-index task",
        "analysis_date": "2026-10-26",
        "threshold_fitting": "176 training records only; existing 45 validation records reused for exploratory assessment",
        "selection_limit": "Morphology descriptors were chosen after inspecting examples and the existing diagnostic; validation is not an untouched confirmatory test.",
        "connectivity": "Black pixels <128; eight-neighbor connected components; crop eight outer pixels to reduce the rendered frame.",
        "lower_region": "Rows 55%-98% of image height, columns 8..width-8; image coordinates, not a calibrated physical ROI.",
        "small_components": "Small: less than 0.5% of cropped image area. Substantial: at least 0.1%.",
        "features": summary,
        "equivalent_brightness_threshold": equivalent_gray,
        "representatives_selected_nearest_training_class_median_dark_coverage": representatives,
        "validation_spearman_dark_coverage_vs_dinov2_high_probability": float(
            spearman.statistic if hasattr(spearman, "statistic") else spearman.correlation
        ),
        "no_neural_training": True,
        "no_new_physical_simulation": True,
    }
    with (HERE / "image_features.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(records[0]))
        writer.writeheader()
        writer.writerows(records)
    (HERE / "analysis.json").write_text(json.dumps(diagnostic, indent=2, allow_nan=False) + "\n")
    print(json.dumps(diagnostic, indent=2))


if __name__ == "__main__":
    main()
