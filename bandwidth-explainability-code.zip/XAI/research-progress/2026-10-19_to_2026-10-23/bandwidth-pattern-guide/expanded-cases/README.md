# Expanded true-positive / false-positive structural atlas

Created 27 October 2026. Open [the 18-page atlas](expanded-structural-atlas.pdf).
It expands the earlier two-error guide with real structural close-ups, signed
attribution maps, new matched-area model probes, similar-area comparisons, and
a complete gallery of the 21 true High validation images.

Two introductory pages now explain bandwidth, the exact High/Low class rule,
true/false positives, signed High-minus-Low attribution, the color meanings,
and how to read the structural crops and deletion plots. They use Roman page
numbers i-ii; the existing analysis retains its original page numbers 1-16.

Bandwidth is the wavelength span over which the device maintains transmission
performance. The dataset uses 0.5 dB bandwidth near 1550 nm and combines the
two modes as `S = BW0 / mean(BW0) + BW1 / mean(BW1)`: Low if `S <= 1.8`, High
if `S >= 2.35`, with intermediate designs excluded. See the
[original definition](https://doi.org/10.1002/adpr.202500284), Section 4.1.

The signed map estimates local attribution to the model's raw High-minus-Low
score: red toward High, blue toward Low, pale for little local attribution.
It is a coarse approximation rather than a complete score decomposition.
Component colors in the zooms only distinguish pieces of the geometry.

**Positive means High throughout.** A true positive (TP) is labelled High and
predicted High. A false positive (FP) is labelled Low but predicted High. These
labels apply to the original images; edited images have no simulated physical
bandwidth labels.

## Complete scope

The original split contains 21 High and 24 Low validation images. The four
archived models have the following counts:

| Model | TP | FP | TN | FN | False-positive images |
| --- | --- | --- | --- | --- | --- |
| CNN | 21 | 1 | 23 | 0 | M93 |
| ViT-Tiny | 21 | 2 | 22 | 0 | M93, M323 |
| DINOv2 | 21 | 2 | 22 | 0 | M93, M95 |
| VMamba | 21 | 1 | 23 | 0 | M93 |

There are six false-positive model/image pairs but only **three distinct FP
images** in these saved predictions. All three are included. All 21 DINOv2
true positives appear in the gallery; eight purposefully varied TPs have
individual explanation pages. This is a visual range selection, not a random
sample or a new estimate of model accuracy.

| Detailed image | Status and model | Structure chosen for examination |
| --- | --- | --- |
| M136 | TP, DINOv2 | Broad connected lower arm and upper-right prongs |
| M10 | TP, DINOv2 | Gap beside a large lower body; central downward tips |
| M11 | TP, DINOv2 | Separate lower lobes; a near-boundary correct prediction |
| M178 | TP, DINOv2 | Sparse lower-left arm, isolated islands and detached right groups |
| M238 | TP, DINOv2 | Two large separated lower pieces; moderate High score |
| M31 | TP, DINOv2 | Chain of lower islands and a detached central group |
| M65 | TP, DINOv2 | Large detached lower-right body |
| M303 | TP, DINOv2 | Connected lower bend with branches and nearby islands |
| M93 | FP, DINOv2 | High-like diagonal lower arm; wrong High in all four models |
| M95 | FP, DINOv2 | Upper-right prongs and lower-right islands; DINOv2-specific error |
| M323 | FP, ViT-Tiny | Curved lower island chain; ViT-specific error |

## What the amplified views show

Each detailed page has an original image marked with regions A and B and an
upper-left comparison region C. The enlarged A/B crops color separate
eight-connected black components, using the original pixel grid. Arrows mark
visible gaps between distinct components. Colors are local to each crop;
uncolored tiny groups remain black. They encode bitmap connectivity, **not
materials, classes, electric fields, or paths followed by light**.

The red contours show the exact subset of 4,096 black pixels whitened in the
new deletion test. A crop's entire feature is not necessarily removed. Each
mask selects the nearest black pixels to its declared center within the ROI;
the center/ROI choices were fixed before new mask responses were computed.
The comparison region C contains actual structure and is not a signal-free
or neutral control.

## New numerical evidence

All 11 unedited case probabilities reproduced their archived predictions to
within 0.0005 absolute probability; the largest observed difference was about
0.00000573. New attribution and edit computations used the exact original
DINOv2 and ViT-Tiny checkpoints, original preprocessing, float32 CPU execution,
and frozen weights. No optimizer or model training was used.

There are three edited-image forwards per detailed case, **33 new mask probes**,
in addition to the forwards and gradients used for the 11 attribution maps.
All masks within a case remove exactly 4,096 black pixels and produce exactly
the same native-image mean brightness. Resizing to the model input can introduce
small remaining mean differences. The edits may be out of distribution.
The largest measured difference in mean grayscale after resizing between the
three masks of a case was 0.000519 on the 0-255 intensity scale.

| Original image | Original P(High) | Mask A | Mask B | Comparison C |
| --- | --- | --- | --- | --- |
| M136 TP | 99.97% | 99.95% | 99.89% | 99.97% |
| M10 TP | 97.87% | 94.52% | 97.12% | 98.10% |
| M11 TP | 50.44% | 50.50% | 39.93% | 64.89% |
| M178 TP | 90.57% | 92.66% | 86.29% | 90.33% |
| M238 TP | 58.23% | 33.75% | 44.11% | 46.98% |
| M31 TP | 96.21% | 94.31% | 96.70% | 95.31% |
| M65 TP | 71.10% | 53.34% | 64.27% | 63.84% |
| M303 TP | 99.45% | 98.84% | 98.88% | 99.31% |
| M93 FP | 94.46% | 91.13% | 90.16% | 92.65% |
| M95 FP | 55.87% | 52.87% | 42.41% | 45.71% |
| M323 FP, ViT | 57.55% | 49.76% | 34.60% | 20.16% |

These are model softmax scores, not calibrated probabilities of physical
bandwidth. The plots also show changes in the High-minus-Low logit margin so
that saturated probabilities, such as M136's, do not hide model sensitivity.
Gallery scores are archived; detailed scores come from newly audited CPU
forwards, so a last displayed decimal can differ due to floating-point drift.

## What can be said about particular structures

- **Broad connectivity is useful but not necessary.** M136 and M303 illustrate
  broad connected High structures, but M178, M31 and M65 are true High examples
  with substantial fragmentation or large gaps.
- **Area alone cannot distinguish the hard cases.** M2 and M93 have only a
  0.177-percentage-point difference in black coverage. M2's largest component
  contains 53.8% of the black area versus M93's 22.9%. This makes lower-region
  connectivity a concrete comparison to inspect, not a proven causal separator.
- **The size distribution of islands adds context.** M178 and M323 differ in
  coverage by only 0.296 percentage points, but small-island shares are 4.8%
  and 16.9%. Their labels are opposite. These examples support measuring
  fragmentation more precisely than simply noticing that islands exist.
- **A correct answer can still be fragile.** M11 flips to Low after mask B;
  M238 flips after A, B and C. Those flips do not establish that one unique
  feature explains true High bandwidth.
- **A local black region can oppose the model's High score.** In M178, removing
  A raises P(High) from 90.57% to 92.66%, whereas removing B lowers it. The role
  of a region depends on its context; not every black pixel is positive High
  evidence.
- **The new FP exposes model disagreement.** ViT-Tiny gives M323 57.55% High,
  while the other three models predict Low. Its comparison region C causes
  a larger score drop than A or B. The selected lower chain is therefore not
  demonstrated to be a uniquely decisive source of the error.

The M93/M95 tests here use smaller, newly defined masks and an upper-left
comparison. They are a separate protocol from the earlier 9,843/9,512-pixel
checks. For example, the new M95 upper-right mask stays High at 52.87%, while
the earlier larger upper-right mask flipped it. Mask size and placement matter.

## Reading the signed map correctly

The atlas reuses the existing Grad-CAM implementation and transformer target
layer `blocks.11.norm1` before final attention. DINOv2 has a 16x16 patch map;
ViT-Tiny has a 14x14 map. Enlarging it does not recover pixel-scale attribution.

For a more class-discriminative view, it derives a signed class-margin map as:

`signed_CAM(High) - signed_CAM(Low)`

Subtraction happens **before** ReLU and before any normalization. It follows
gradient linearity for the target `High logit - Low logit`; the synthetic check
compares it with a known analytical margin. Red and blue mark the local
direction of attribution at that layer; each map has its own symmetric scale.
Magnitudes cannot be compared between images.

This is a local, coarse attribution approximation, not a complete or conserved
decomposition of the final score. In particular, M323's mostly Low-directed
map can coexist with its predicted High class. It must not be read as a new
Low prediction, nor as a complete account of ViT-Tiny's decision. The actual
finite edits provide an additional, different check and can disagree with a
local-gradient interpretation.

## Boundaries and physical follow-up

The broader comparison does not yield a universal geometric definition of
bandwidth. It improves the visual vocabulary and tests model sensitivity.
Exact material mapping, transmission spectra and controlled electromagnetic
simulations are needed before claiming a candidate feature changes physical
bandwidth. This work neither changes ground-truth labels nor simulates edited
devices. The original validation partition is reused and remains small.

Primary references: [Grad-CAM](https://arxiv.org/abs/1610.02391) and
[the original photonic dataset paper](https://doi.org/10.1002/adpr.202500284).
The signed-margin variant is explicitly derived here; the transformer adapters
are the local project's implementation, not a claim that a pixel heatmap is
an optical simulation.

## Files and reproducibility

- `expanded-structural-atlas.pdf`: two introductory pages followed by 16 analysis pages.
- Numbered PNG/SVG figures: individual pages for reuse and editing.
- `results.json`: complete archive counts, case definitions, score audits,
  model comparisons, target layers, checkpoint hashes and all probe outputs.
- `data/<sample>/maps-and-masks.npz`: signed/native maps and exact boolean masks.
- `cases.py`: declared examples, regions, mask centers and structural observations.
- `analyze_cases.py`: no-training CPU analysis using existing shared functions.
- `test_cases.py`: four synthetic checks of area matching, mask validity and
  class-margin linearity.
- `build_atlas.py`: rendering from saved numerical results.
- `mask-probe-results.csv`: the 33 edited-image probe records in tabular form.
- `verification.json`: input, checkpoint, map, mask, score and output checks.
- `executed-source/cases.py`: exact case declarations used for inference;
  the current formatted version has an equivalent syntax tree.
- `formatting-verification.json`: before/after code hashes and syntax-tree checks.

Use the original-bandwidth project's existing `.venv/bin/python -B` from this
directory to run the scripts. No research dependency was added. The analysis
checks checkpoint predictions against the archive and checks model state hashes
before and after attribution/probes. The original guide and scientific outputs
remain separate from these new results.
All PDF pages were rendered; the introduction and original analysis were
visually inspected. All 221 source-image
checksums still match the earlier guide, both checkpoint file hashes match,
and the four synthetic tests passed. Generated review intermediates were
removed; numbered PNGs and editable SVGs are retained as final figures.
