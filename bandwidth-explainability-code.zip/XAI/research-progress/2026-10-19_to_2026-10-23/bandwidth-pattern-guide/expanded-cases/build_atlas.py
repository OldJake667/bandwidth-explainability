"""Illustrated structural atlas: real crops, topology, margin maps, mask probes."""

import csv
import json
from pathlib import Path
import subprocess
import textwrap

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.colors import Normalize
from matplotlib.patches import Rectangle, FancyArrowPatch
import numpy as np
from PIL import Image
from scipy import ndimage

from cases import CASES, CONTROL_ROI

HERE = Path(__file__).resolve().parent
ROOT = next(p for p in HERE.parents if (p / "model-training").is_dir())
REPORT = json.loads((HERE / "results.json").read_text())
BY_ID = {r["sample"]: r for r in REPORT["cases"]}
FEATURES = {
    r["file"].split("_")[0]: r for r in csv.DictReader((HERE.parent / "image_features.csv").open())
}
QA = HERE / "tmp/pdfs"
QA.mkdir(parents=True, exist_ok=True)
COLORS = {
    "TP": "#007d83",
    "FP": "#b32635",
    "ink": "#172b3b",
    "muted": "#526373",
    "A": "#b65e00",
    "B": "#008366",
    "C": "#657180",
}
NAMES = {"dinov2": "DINOv2", "vit_tiny": "ViT-Tiny", "cnn": "CNN", "vmamba": "VMamba"}
plt.rcParams.update(
    {
        "font.family": "DejaVu Sans",
        "font.size": 11,
        "axes.spines.top": False,
        "axes.spines.right": False,
        "pdf.fonttype": 42,
        "svg.fonttype": "none",
        "axes.unicode_minus": False,
    }
)


def gray(sample):
    return np.asarray(Image.open(ROOT / FEATURES[sample]["image_path"]).convert("L"))


def text(fig, x, y, message, width=45, size=10.5, color="ink", weight="normal"):
    fig.text(
        x,
        y,
        "\n".join(textwrap.fill(line, width=width) for line in message.split("\n")),
        va="top",
        fontsize=size,
        color=COLORS.get(color, color),
        weight=weight,
        linespacing=1.35,
    )


def page(title, subtitle, number):
    fig = plt.figure(figsize=(14, 10), facecolor="white")
    text(fig, 0.045, 0.96, title, width=90, size=22, weight="bold")
    text(fig, 0.045, 0.91, subtitle, width=135, size=11, color="muted")
    fig.text(
        0.045,
        0.025,
        "Original Low/High bandwidth dataset | Frozen CPU inference | Edited physical bandwidth not simulated | 27 October 2026",
        fontsize=8.7,
        color=COLORS["muted"],
    )
    fig.text(0.96, 0.025, str(number), ha="right", fontsize=9, color=COLORS["muted"])
    return fig


def bounds(roi, image):
    h, w = image.shape
    return tuple(int(value * (w if i % 2 == 0 else h)) for i, value in enumerate(roi))


def show_original(fig, rectangle, sample, regions=None):
    ax = fig.add_axes(rectangle)
    image = gray(sample)
    ax.imshow(image, cmap="gray", vmin=0, vmax=255, interpolation="nearest")
    ax.set_axis_off()
    if regions:
        for label, roi in regions.items():
            x0, y0, x1, y1 = bounds(roi, image)
            ax.add_patch(
                Rectangle(
                    (x0, y0),
                    x1 - x0,
                    y1 - y0,
                    fill=False,
                    edgecolor=COLORS[label],
                    linewidth=1.5,
                    linestyle="--" if label == "C" else "-",
                )
            )
            ax.text(
                x0 + 3,
                y0 + 18,
                label,
                color=COLORS[label],
                fontsize=11,
                weight="bold",
                bbox={"facecolor": "white", "edgecolor": "none", "pad": 1},
            )
    return ax


def bandwidth_introduction():
    fig = page(
        "What do High and Low bandwidth mean?",
        "Bandwidth is the wavelength range over which the photonic device maintains its transmission performance.",
        "i",
    )
    text(fig, 0.055, 0.835, "Higher bandwidth", size=16, weight="bold")
    text(
        fig,
        0.055,
        0.79,
        "The device maintains performance across a wider span of light wavelengths.",
        width=52,
        size=12,
    )
    text(fig, 0.55, 0.835, "Lower bandwidth", size=16, weight="bold")
    text(
        fig,
        0.55,
        0.79,
        "The device maintains performance across a narrower span of light wavelengths.",
        width=52,
        size=12,
    )
    ax = fig.add_axes([0.13, 0.435, 0.75, 0.235])
    ax.barh([1, 0], [100, 200], left=[1500, 1450], height=0.34, color=["#578196", "#007d83"])
    ax.axvline(1550, color=COLORS["muted"], lw=1, linestyle="--")
    ax.text(1550, 1.27, "1500-1600 nm: bandwidth 100 nm", ha="center", fontsize=11)
    ax.text(1550, 0.27, "1450-1650 nm: bandwidth 200 nm", ha="center", fontsize=11)
    ax.set(
        xlim=(1430, 1670),
        ylim=(-0.35, 1.62),
        yticks=[1, 0],
        yticklabels=["Narrower example", "Wider example"],
        xlabel="Light wavelength (nm)",
    )
    ax.spines["left"].set_visible(False)
    ax.tick_params(axis="y", length=0)
    text(
        fig,
        0.13,
        0.385,
        "Illustrative spans only. The actual dataset labels combine the bandwidths of two propagation modes.",
        width=110,
        size=10.5,
        color="muted",
    )
    text(
        fig,
        0.055,
        0.325,
        "How the original dataset defines the labels",
        width=100,
        size=15,
        weight="bold",
    )
    text(
        fig,
        0.055,
        0.28,
        "It uses 0.5 dB bandwidth: transmission stays within 0.5 dB of its reference peak near 1550 nm. Each mode's bandwidth is divided by that mode's dataset mean, then the two normalized values are added:",
        width=128,
        size=11.5,
    )
    fig.text(
        0.055,
        0.177,
        r"$S=BW_0/\langle BW_0\rangle + BW_1/\langle BW_1\rangle$",
        fontsize=15,
        color=COLORS["ink"],
    )
    text(
        fig,
        0.55,
        0.185,
        "Low: S <= 1.8     High: S >= 2.35\nIntermediate designs were excluded.",
        width=60,
        size=12,
        weight="bold",
    )
    text(
        fig,
        0.055,
        0.117,
        "The true labels come from optical transmission spectra. The image analysis investigates which geometric features the models associate with those labels.",
        width=130,
        size=11,
    )
    text(
        fig,
        0.055,
        0.067,
        "Source: Pira et al., Section 4.1. https://doi.org/10.1002/adpr.202500284",
        width=135,
        size=9.5,
        color="muted",
    )
    return fig


def attribution_introduction():
    fig = page(
        "How to read the predictions and colored maps",
        "Keep three things separate: the true bandwidth label, the model's prediction, and its estimated local attribution.",
        "ii",
    )
    text(fig, 0.055, 0.835, "High minus Low", size=15, weight="bold")
    text(
        fig,
        0.055,
        0.79,
        "This is the difference between two internal raw model scores (logits). A positive difference favors High; a negative difference favors Low.",
        width=55,
        size=11.5,
    )
    text(fig, 0.55, 0.835, "Positive means High", size=15, weight="bold")
    text(
        fig,
        0.55,
        0.79,
        "True positive: labelled High, predicted High.\nFalse positive: labelled Low, predicted High.",
        width=57,
        size=11.5,
    )
    text(
        fig,
        0.055,
        0.665,
        "Signed attribution: which regions locally favor High rather than Low?",
        width=110,
        size=14,
        weight="bold",
    )
    ax = fig.add_axes([0.11, 0.555, 0.78, 0.04])
    ax.imshow(np.linspace(-1, 1, 512)[None], cmap="RdBu_r", aspect="auto", vmin=-1, vmax=1)
    ax.set_axis_off()
    text(fig, 0.11, 0.63, "Blue: toward Low", width=28, size=11)
    text(fig, 0.405, 0.63, "Pale: little local attribution", width=36, size=11)
    text(fig, 0.74, 0.63, "Red: toward High", width=30, size=11)
    for x, title, body in [
        (
            0.055,
            "Original geometry",
            "Black and white show the device pattern. The bitmap's material mapping must be checked separately.",
        ),
        (
            0.375,
            "Colored zoom crops",
            "Colors separate black connected components. They do not label High or Low. Gap arrows are not paths followed by light.",
        ),
        (
            0.695,
            "Deletion-test plots",
            "A/B mark selected regions; C is a comparison region. Each mask whitens 4096 black pixels. Negative bars reduce the High-Low margin; positive bars increase it.",
        ),
    ]:
        text(fig, x, 0.475, title, width=34, size=13, weight="bold")
        text(fig, x, 0.43, body, width=38, size=11)
    text(
        fig,
        0.055,
        0.245,
        "A heatmap is a coarse local estimate, not a complete breakdown of the final score. A mostly blue map can coexist with a High prediction, as in M323. Read it together with the actual deletion responses.",
        width=125,
        size=11.5,
    )
    text(
        fig,
        0.055,
        0.155,
        "P(High) is the model's softmax score. It is not a calibrated probability of physical bandwidth. Each heatmap is scaled separately, so compare locations and signs rather than color strength across images.",
        width=128,
        size=11,
    )
    text(
        fig,
        0.055,
        0.075,
        "Method background: Grad-CAM, https://arxiv.org/abs/1610.02391. The signed High-Low extension is explained in README.md.",
        width=135,
        size=9.5,
        color="muted",
    )
    return fig


def component_crop(image, roi):
    black = image < 128
    black[:8] = False
    black[-8:] = False
    black[:, :8] = False
    black[:, -8:] = False
    labels, _ = ndimage.label(black, structure=np.ones((3, 3)))
    x0, y0, x1, y1 = bounds(roi, image)
    crop = image[y0:y1, x0:x1]
    local = labels[y0:y1, x0:x1]
    rgb = np.repeat((crop / 255)[..., None], 3, axis=2)
    sizes = np.bincount(local.ravel())
    ids = sorted(
        (i for i in range(1, len(sizes)) if sizes[i] >= 100), key=lambda i: sizes[i], reverse=True
    )
    palette = plt.get_cmap("tab10")
    for rank, label in enumerate(ids[:8]):
        rgb[local == label] = palette(rank)[:3]
    return rgb, local, ids


def zoom(fig, rectangle, record, label, arrays):
    image = gray(record["sample"])
    roi = record[label.lower()]
    x0, y0, x1, y1 = bounds(roi, image)
    rgb, components, ids = component_crop(image, roi)
    ax = fig.add_axes(rectangle)
    ax.imshow(rgb, interpolation="nearest")
    mask = arrays["mask_" + label][y0:y1, x0:x1]
    if mask.any() and not mask.all():
        ax.contour(mask, levels=[0.5], colors=[COLORS["FP"]], linewidths=0.9)
    if len(ids) >= 2:
        distance, nearest = ndimage.distance_transform_edt(
            components != ids[1], return_indices=True
        )
        choices = np.where(components == ids[0], distance, np.inf)
        yy, xx = np.unravel_index(np.argmin(choices), choices.shape)
        yy2, xx2 = nearest[:, yy, xx]
        ax.annotate(
            "", (xx2, yy2), (xx, yy), arrowprops={"arrowstyle": "<->", "color": "#252525", "lw": 1}
        )
        ax.text(
            (xx + xx2) / 2,
            (yy + yy2) / 2 - 6,
            "gap",
            fontsize=8,
            ha="center",
            color="#111111",
            bbox={"facecolor": "white", "edgecolor": "none", "alpha": 0.9, "pad": 1},
        )
    ax.set_axis_off()
    feature = record["feature_" + label.lower()]
    ax.set_title(
        label + ": " + "\n".join(textwrap.wrap(feature, 31)),
        fontsize=11,
        color=COLORS[label],
        loc="left",
        pad=8,
    )
    magnification = rectangle[2] / 0.25 / (roi[2] - roi[0])
    fig.text(
        rectangle[0],
        0.515,
        f"Approx. {magnification:.1f}x relative to the original panel",
        fontsize=8.7,
        color=COLORS["muted"],
    )


def outcome_text(record):
    probes = {p["region"]: p for p in record["probes"]}
    strongest = min(probes.values(), key=lambda p: p["delta_margin"])
    if strongest["region"] == "C":
        return f"The upper-left comparison C causes the largest margin drop. Its P(High) is {probes['C']['probability_high']:.2%}; neither A nor B is shown to be uniquely dominant."
    label = strongest["region"]
    p = strongest["probability_high"]
    control = probes["C"]["probability_high"]
    return f"Mask {label} gives the largest margin drop. P(High) becomes {p:.2%}, versus {control:.2%} for equal-area C. This is local model sensitivity, not a physical bandwidth change."


def case_page(record, number):
    sample, kind = record["sample"], record["kind"]
    title = f"{sample} | {'True positive' if kind == 'TP' else 'False positive'}: {record['title']}"
    subtitle = f"{NAMES[record['model']]} | true {'High' if record['true_label'] else 'Low'} | predicted High | P(High) {record['probability_high']:.2%} | Positive class = High"
    fig = page(title, subtitle, number)
    image = gray(sample)
    arrays = np.load(HERE / "data" / sample / "maps-and-masks.npz")
    ax = show_original(
        fig,
        [0.045, 0.48, 0.25, 0.34],
        sample,
        {"A": record["a"], "B": record["b"], "C": CONTROL_ROI},
    )
    ax.set_title("Original image: A/B regions; C comparison", fontsize=10.5, loc="left", pad=9)
    zoom(fig, [0.36, 0.555, 0.275, 0.245], record, "A", arrays)
    zoom(fig, [0.69, 0.555, 0.275, 0.245], record, "B", arrays)
    text(
        fig,
        0.36,
        0.485,
        "Component colors are local to each crop; tiny pieces stay black. Red outlines mark the tested 4,096-pixel deletion. Arrows mark visible gaps, not light propagation.",
        width=89,
        size=9.5,
        color="muted",
    )
    cam = fig.add_axes([0.045, 0.145, 0.25, 0.265])
    signed = arrays["contrastive_signed_upsampled"]
    limit = float(np.abs(arrays["contrastive_signed_native"]).max()) or 1.0
    cam.imshow(image, cmap="gray", vmin=0, vmax=255)
    cam.imshow(
        signed,
        cmap="RdBu_r",
        vmin=-limit,
        vmax=limit,
        alpha=0.8 * np.clip(np.abs(signed) / limit, 0, 1),
    )
    cam.set_axis_off()
    cam.set_title("Signed attribution to High minus Low", fontsize=10.5, loc="left", pad=8)
    color_ax = fig.add_axes([0.065, 0.117, 0.21, 0.012])
    bar = fig.colorbar(
        plt.cm.ScalarMappable(norm=Normalize(-1, 1), cmap="RdBu_r"),
        cax=color_ax,
        orientation="horizontal",
    )
    bar.set_ticks([-1, 0, 1], labels=["toward Low", "0", "toward High"])
    bar.ax.tick_params(labelsize=8, length=0)
    fig.text(
        0.045,
        0.07,
        "Coarse local map, scaled separately per image.",
        fontsize=9,
        color=COLORS["muted"],
    )
    probe_ax = fig.add_axes([0.405, 0.205, 0.23, 0.185])
    probes = record["probes"]
    delta = [p["delta_margin"] for p in probes]
    probe_ax.bar(range(3), delta, color=[COLORS[p["region"]] for p in probes], width=0.6)
    probe_ax.axhline(0, color="#233344", lw=0.8)
    probe_ax.set_xticks(range(3), ["A", "B", "C"])
    probe_ax.set_title("Matched-area deletion test", fontsize=11, loc="left")
    probe_ax.set_ylabel("Change in High-Low logit margin", fontsize=9)
    lower, upper = min(delta + [0]), max(delta + [0])
    padding = max((upper - lower) * 0.25, 0.12)
    probe_ax.set_ylim(lower - padding, upper + padding)
    for i, value in enumerate(delta):
        probe_ax.text(
            i,
            value + (padding * 0.12 if value >= 0 else -padding * 0.12),
            f"{value:+.3f}",
            ha="center",
            va="bottom" if value >= 0 else "top",
            fontsize=9,
        )
    probabilities = " | ".join(f"{p['region']}: {p['probability_high']:.2%}" for p in probes)
    text(fig, 0.37, 0.16, "P(High) after masking\n" + probabilities, width=42, size=9.5)
    text(
        fig,
        0.37,
        0.095,
        "A, B and C whiten exactly 4,096 black pixels. Their native-image brightness is identical.",
        width=43,
        size=9.2,
        color="muted",
    )
    text(fig, 0.69, 0.418, "Visible structure", width=42, size=11, weight="bold")
    text(fig, 0.69, 0.39, record["observation"], width=43, size=10)
    text(fig, 0.69, 0.31, "What the new model probe says", width=42, size=11, weight="bold")
    text(fig, 0.69, 0.281, outcome_text(record), width=44, size=10)
    text(fig, 0.69, 0.177, "Interpretation", width=42, size=11, weight="bold")
    lesson = record["lesson"]
    if sample == "M323":
        lesson = "ViT-Tiny alone predicts High. Its mostly Low-directed signed map is a local approximation, not a complete score breakdown. Region C has the largest mask effect."
    text(fig, 0.69, 0.148, lesson, width=45, size=9.7)
    return fig


def overview():
    fig = page(
        "True High predictions and false High predictions",
        "Expanded structural atlas: eight varied true positives, all three distinct false-positive images, and all 21 true positives in the gallery.",
        1,
    )
    text(
        fig,
        0.055,
        0.84,
        "TP: labelled High, predicted High.\nFP: labelled Low, predicted High.",
        width=60,
        size=14,
        weight="bold",
    )
    text(
        fig,
        0.55,
        0.84,
        "The same 45 validation images are reused.\nNo independent test set or new physics is introduced.",
        width=56,
        size=12,
    )
    for i, name in enumerate(["cnn", "vit_tiny", "dinov2", "vmamba"]):
        x = 0.055 + 0.235 * i
        groups = REPORT["archived_validation_cases"][name]
        text(fig, x, 0.715, NAMES[name], width=25, size=13, weight="bold")
        text(
            fig,
            x,
            0.675,
            f"TP {len(groups['TP'])} | FP {len(groups['FP'])}\nTN {len(groups['TN'])} | FN {len(groups['FN'])}",
            width=26,
            size=11,
        )
    for i, sample in enumerate(["M136", "M178", "M93", "M323"]):
        x = 0.05 + 0.24 * i
        record = BY_ID[sample]
        ax = show_original(fig, [x, 0.23, 0.205, 0.30], sample)
        ax.set_title(
            f"{sample}: {record['kind']} ({NAMES[record['model']]})",
            fontsize=11,
            color=COLORS[record["kind"]],
            loc="left",
        )
        text(
            fig,
            x,
            0.21,
            {
                "M136": "Broad and continuous",
                "M178": "Sparse but truly High",
                "M93": "Shared false High",
                "M323": "ViT-only false High",
            }[sample],
            width=28,
            size=10,
        )
    text(
        fig,
        0.055,
        0.13,
        "Reading each case: original image -> enlarged structural crops -> signed class-margin map -> equal-area deletion response.",
        width=124,
        size=11,
    )
    text(
        fig,
        0.055,
        0.08,
        "Component colors show connectivity in the bitmap. Heatmap colors show local model attribution. Neither is an optical field map.",
        width=125,
        size=10,
        color="muted",
    )
    return fig


def comparisons(number):
    fig = page(
        "Nearly the same black area, different true labels",
        "Two visual comparisons selected for similar coverage. These are observations, not controlled before/after physical devices.",
        number,
    )
    for i, sample in enumerate(["M2", "M93", "M178", "M323"]):
        row = FEATURES[sample]
        x = 0.04 + 0.245 * i
        ax = show_original(fig, [x, 0.47, 0.22, 0.32], sample)
        ax.set_title(
            f"{sample}: true {row['class_name']}",
            fontsize=13,
            loc="left",
            color=COLORS["TP" if row["class_name"] == "High" else "FP"],
        )
        crop_ax = fig.add_axes([x, 0.30, 0.22, 0.14])
        image = gray(sample)
        rgb, _, _ = component_crop(image, (0.04, 0.63, 0.98, 0.98))
        crop_ax.imshow(rgb, interpolation="nearest")
        crop_ax.set_axis_off()
        text(
            fig,
            x,
            0.26,
            f"Black area: {float(row['dark_coverage']):.2%}\nLargest component:\n{float(row['largest_component_fraction']):.1%} of black area\nSmall-island share: {float(row['small_island_fraction']):.1%}",
            width=28,
            size=10.5,
        )
    text(
        fig,
        0.045,
        0.13,
        "M2 vs M93: almost equal coverage, but the lower black body is much more connected in M2.",
        width=115,
        size=12,
        weight="bold",
    )
    text(
        fig,
        0.045,
        0.087,
        "M178 vs M323: both look sparse; their labels differ. Coverage and a rough visual category cannot certify bandwidth.",
        width=124,
        size=11,
    )
    return fig


def gallery(samples, number, suffix):
    fig = page(
        "All 21 true positives: " + suffix,
        "DINOv2 original validation predictions. Every true High image is included; the gallery is not filtered by confidence.",
        number,
    )
    for i, sample in enumerate(samples):
        col, row = i % 4, i // 4
        x, y = 0.04 + 0.24 * col, 0.63 - 0.28 * row
        ax = show_original(fig, [x, y, 0.205, 0.20], sample)
        probability = float(FEATURES[sample]["dinov2_probability_high"])
        ax.set_title(f"{sample}: P(High) {probability:.2%}", fontsize=10, loc="left", pad=5)
    return fig


def synthesis(number):
    fig = page(
        "A structural explanation needs several levels of evidence",
        "The atlas expands the visual vocabulary and tests which regions influence each classifier. It does not establish a universal shape rule.",
        number,
    )
    items = [
        ("M136", "Broad connected arm"),
        ("M178", "Sparse true High"),
        ("M93", "High-like true Low"),
        ("M323", "Model disagreement"),
    ]
    for i, (sample, label) in enumerate(items):
        x = 0.05 + 0.24 * i
        roi = BY_ID[sample]["a"]
        rgb, _, _ = component_crop(gray(sample), roi)
        ax = fig.add_axes([x, 0.63, 0.205, 0.16])
        ax.imshow(rgb, interpolation="nearest")
        ax.set_axis_off()
        ax.set_title(f"{sample}: {label}", fontsize=10.5, loc="left")
    steps = [
        ("OBSERVE", "Describe width, gaps, islands and continuity on enlarged real crops."),
        ("COMPARE", "Check true High and false High examples, including similar-area pairs."),
        ("PROBE", "Use signed attribution and matched-area edits to test model sensitivity."),
        (
            "VALIDATE",
            "Recompute the optical spectra before claiming the feature changes bandwidth.",
        ),
    ]
    for i, (title, body) in enumerate(steps):
        x = 0.045 + 0.24 * i
        fig.patches.append(
            Rectangle(
                (x, 0.32),
                0.205,
                0.19,
                transform=fig.transFigure,
                facecolor="#f3f6f8",
                edgecolor="#c7d0d8",
            )
        )
        text(fig, x + 0.012, 0.49, title, width=25, size=12, weight="bold")
        text(fig, x + 0.012, 0.45, body, width=28, size=10.5)
        if i < 3:
            fig.patches.append(
                FancyArrowPatch(
                    (x + 0.21, 0.41),
                    (x + 0.235, 0.41),
                    transform=fig.transFigure,
                    arrowstyle="-|>",
                    mutation_scale=14,
                    color=COLORS["muted"],
                )
            )
    text(
        fig, 0.05, 0.245, "What survives the broader comparison", width=100, size=14, weight="bold"
    )
    text(
        fig,
        0.05,
        0.204,
        "Broad connected regions are common High-like cues, but they are neither necessary nor sufficient. Sparse High designs and convincing false High designs both exist.",
        width=123,
        size=12,
    )
    text(
        fig,
        0.05,
        0.135,
        "M11 and M238 are sensitive near-boundary true positives. In M323, the comparison region C affects ViT-Tiny more than A or B: the selected local shape is not uniquely decisive.",
        width=133,
        size=10.5,
    )
    text(
        fig,
        0.05,
        0.079,
        "Methods: reused Grad-CAM workflow; signed High-CAM minus Low-CAM before ReLU/normalization. See README.md and results.json for inputs, audit tolerances and exact probe outputs.",
        width=140,
        size=9.5,
        color="muted",
    )
    return fig


def main():
    figures = [("01-overview", overview())]
    for record in REPORT["cases"]:
        number = len(figures) + 1
        figures.append(
            (f"{number:02d}-{record['sample']}-{record['kind'].lower()}", case_page(record, number))
        )
    figures.append(("13-similar-area-comparisons", comparisons(13)))
    samples = REPORT["archived_validation_cases"]["dinov2"]["TP"]
    figures.append(("14-all-true-positives-1", gallery(samples[:12], 14, "1 of 2")))
    figures.append(("15-all-true-positives-2", gallery(samples[12:], 15, "2 of 2")))
    figures.append(("16-structural-reasoning", synthesis(16)))
    figures = [
        ("00-bandwidth-explained", bandwidth_introduction()),
        ("00-reading-the-figures", attribution_introduction()),
        *figures,
    ]
    with PdfPages(HERE / "expanded-structural-atlas.pdf") as pdf:
        for name, fig in figures:
            fig.savefig(HERE / (name + ".png"), dpi=155)
            fig.savefig(HERE / (name + ".svg"))
            pdf.savefig(fig)
            fig.savefig(QA / (name + ".pdf"))
            result = subprocess.run(
                [
                    "sips",
                    "-s",
                    "format",
                    "png",
                    str(QA / (name + ".pdf")),
                    "--out",
                    str(QA / (name + ".png")),
                ],
                capture_output=True,
                text=True,
            )
            assert result.returncode == 0, result.stderr
            plt.close(fig)
            print("Rendered " + name, flush=True)
    (HERE / "pages.json").write_text(json.dumps([name for name, _ in figures], indent=2) + "\n")
    print("Finished 18-page structural atlas, including two introductory pages.", flush=True)


if __name__ == "__main__":
    main()
