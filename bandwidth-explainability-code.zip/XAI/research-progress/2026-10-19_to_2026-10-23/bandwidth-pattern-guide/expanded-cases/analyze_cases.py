"""Fresh CPU attribution and matched-area probes, with frozen original models."""

import csv
import hashlib
import json
from pathlib import Path
import sys

import numpy as np
from PIL import Image
import torch

from cases import CASES, MASK_PIXELS, CONTROL_ROI, CONTROL_CENTER

HERE = Path(__file__).resolve().parent
RESEARCH = next(p for p in HERE.parents if (p / "model-training").is_dir())
PROJECT = RESEARCH / "model-training/original-bandwidth-replication/undated/local-work"
LAB = PROJECT / "original_bandwidth_explainability_lab"
WORKFLOW = (
    RESEARCH
    / "model-training/rdn-pretrained-finetuning/2026-10-16_to_2026-10-19/local-work/gradcam_xai"
)
sys.path.insert(0, str(LAB))
sys.path.insert(0, str(WORKFLOW))
from xai_code.models import build_model, Predictor
from workflow import gradcam, target_layer, resize_map, state_hash, sha256


def region_bounds(roi, shape):
    height, width = shape
    x0, y0, x1, y1 = roi
    assert 0 <= x0 < x1 <= 1 and 0 <= y0 < y1 <= 1
    return int(x0 * width), int(y0 * height), int(x1 * width), int(y1 * height)


def black_mask(gray, roi, center, count=MASK_PIXELS):
    x0, y0, x1, y1 = region_bounds(roi, gray.shape)
    yy, xx = np.where(gray[y0:y1, x0:x1] < 128)
    yy, xx = yy + y0, xx + x0
    if len(xx) < count:
        raise ValueError(f"ROI has only {len(xx)} black pixels; {count} required")
    cx, cy = center[0] * gray.shape[1], center[1] * gray.shape[0]
    distance = (xx - cx) ** 2 + (yy - cy) ** 2
    chosen = np.argsort(distance, kind="stable")[:count]
    mask = np.zeros(gray.shape, dtype=bool)
    mask[yy[chosen], xx[chosen]] = True
    assert mask.sum() == count and np.all(gray[mask] == 0)
    return mask


def contrastive_native(result):
    # Subtract signed CAMs before ReLU or normalization; gradients are linear.
    contrast = result["maps"][1]["signed_native"] - result["maps"][0]["signed_native"]
    assert np.isfinite(contrast).all()
    return contrast


def main():
    torch.set_num_threads(4)
    torch.manual_seed(42)
    np.random.seed(42)
    features = {
        r["file"].split("_")[0]: r
        for r in csv.DictReader((HERE.parent / "image_features.csv").open())
    }
    archived = {}
    counts = {}
    for name in ["cnn", "vit_tiny", "dinov2", "vmamba"]:
        rows = list(
            csv.DictReader((LAB / f"reference/{name}/best_accuracy_predictions.csv").open())
        )
        archived[name] = {r["file"].split("_")[0]: r for r in rows}
        groups = {key: [] for key in ["TP", "FP", "TN", "FN"]}
        for row in rows:
            truth, predicted = int(row["true_label"]), int(row["predicted_label"])
            group = ("TP" if truth else "FP") if predicted else ("FN" if truth else "TN")
            groups[group].append(row["file"].split("_")[0])
        counts[name] = groups
    assert set().union(*(set(g["FP"]) for g in counts.values())) == {"M93", "M95", "M323"}
    assert len(counts["dinov2"]["TP"]) == 21
    records = []
    for case in CASES:
        row = features[case["sample"]]
        assert row["split"] == "validation"
        assert case["sample"] in counts[case["model"]][case["kind"]]
        gray = np.asarray(Image.open(RESEARCH / row["image_path"]).convert("L"))
        for roi, center in [
            (case["a"], case["center_a"]),
            (case["b"], case["center_b"]),
            (CONTROL_ROI, CONTROL_CENTER),
        ]:
            black_mask(gray, roi, center)
    for model_name in ["dinov2", "vit_tiny"]:
        model = build_model(LAB, model_name, "cpu")
        predictor = Predictor(model, model_name, "cpu", batch_size=1)
        initial_hash = state_hash(model)
        layer, layer_name, layout, grid = target_layer(model, model_name)
        for case in [c for c in CASES if c["model"] == model_name]:
            sample = case["sample"]
            row = features[sample]
            gray = np.asarray(Image.open(RESEARCH / row["image_path"]).convert("L"))
            rgb = np.repeat(gray[..., None], 3, axis=2)
            tensor = predictor.tensor(rgb)[None]
            result = gradcam(model, layer, tensor, layout, grid)
            prior = archived[model_name][sample]
            difference = float(
                np.max(
                    np.abs(
                        result["probabilities"]
                        - [float(prior["probability_low"]), float(prior["probability_high"])]
                    )
                )
            )
            assert difference <= 0.0005, (sample, difference)
            assert int(result["probabilities"].argmax()) == int(prior["predicted_label"])
            contrasts = contrastive_native(result)
            directory = HERE / "data" / sample
            directory.mkdir(parents=True, exist_ok=True)
            masks = {
                "A": black_mask(gray, case["a"], case["center_a"]),
                "B": black_mask(gray, case["b"], case["center_b"]),
                "C": black_mask(gray, CONTROL_ROI, CONTROL_CENTER),
            }
            probes = []
            arrays = {
                "contrastive_signed_native": contrasts,
                "contrastive_signed_upsampled": resize_map(contrasts, gray.shape),
            }
            for label, name in [(0, "low"), (1, "high")]:
                arrays[name + "_signed_native"] = result["maps"][label]["signed_native"]
                arrays[name + "_upsampled"] = resize_map(
                    result["maps"][label]["normalized_native"], gray.shape
                )
            original_margin = float(result["logits"][1] - result["logits"][0])
            for name, mask in masks.items():
                edited = rgb.copy()
                edited[mask] = 255
                with torch.no_grad():
                    logits = model(predictor.tensor(edited)[None])[0].numpy()
                    probability = float(torch.from_numpy(logits).softmax(0)[1])
                margin = float(logits[1] - logits[0])
                probes.append(
                    {
                        "region": name,
                        "masked_black_pixels": int(mask.sum()),
                        "mean_gray_after_mask": float(edited[..., 0].mean()),
                        "probability_high": probability,
                        "predicted_label": int(probability >= 0.5),
                        "logit_margin_high_minus_low": margin,
                        "delta_margin": margin - original_margin,
                        "delta_probability_high_percentage_points": 100
                        * (probability - float(result["probabilities"][1])),
                    }
                )
                arrays["mask_" + name] = mask
            assert len({probe["mean_gray_after_mask"] for probe in probes}) == 1
            np.savez_compressed(directory / "maps-and-masks.npz", **arrays)
            model_scores = {
                name: {
                    "probability_high": float(values[sample]["probability_high"]),
                    "predicted_label": int(values[sample]["predicted_label"]),
                }
                for name, values in archived.items()
            }
            record = {
                **case,
                "true_label": int(row["label"]),
                "probability_high": float(result["probabilities"][1]),
                "logit_margin_high_minus_low": original_margin,
                "max_archived_probability_difference": difference,
                "target_layer": layer_name,
                "grid": grid,
                "hook_max_logit_difference": result["hook_max_logit_difference"],
                "input_image_sha256": row["image_sha256"],
                "checkpoint_sha256": sha256(LAB / f"checkpoints/{model_name}_best_accuracy.pth"),
                "source_image": row["image_path"],
                "model_comparison": model_scores,
                "features": {
                    key: float(row[key])
                    for key in [
                        "dark_coverage",
                        "largest_component_fraction",
                        "small_island_fraction",
                        "lower_component_span",
                    ]
                },
                "probes": probes,
                "edited_geometry_physical_bandwidth": "not simulated",
            }
            (directory / "case.json").write_text(json.dumps(record, indent=2) + "\n")
            records.append(record)
            print(
                f"{sample} {model_name} {case['kind']} P(High)={record['probability_high']:.4f}; audited; three matched masks complete",
                flush=True,
            )
        assert state_hash(model) == initial_hash
        assert all(not p.requires_grad and p.grad is None for p in model.parameters())
        assert not layer._forward_hooks
        del model, predictor
    ordered = [next(r for r in records if r["sample"] == c["sample"]) for c in CASES]
    report = {
        "date": "2026-10-27",
        "positive_class": "High",
        "archived_validation_cases": counts,
        "cases": ordered,
        "mask_pixels_each": MASK_PIXELS,
        "control_roi": CONTROL_ROI,
        "selection": "Eight visually varied DINOv2 TPs and all three distinct FP images across the four archived models. Selected before new mask responses.",
        "contrastive_map": "Signed High CAM minus signed Low CAM before ReLU/normalization; a coarse local attribution to the High-minus-Low logit margin.",
        "cpu_inference": True,
        "new_mask_forward_passes": len(ordered) * 3,
        "training": False,
        "weights_unchanged": True,
        "new_physics": False,
        "source_code_sha256": {
            str(p.relative_to(RESEARCH)): sha256(p)
            for p in [WORKFLOW / "workflow.py", LAB / "xai_code/models.py", HERE / "cases.py"]
        },
    }
    (HERE / "results.json").write_text(json.dumps(report, indent=2, allow_nan=False) + "\n")
    print(
        "Finished 11 audited cases and 33 matched-area model probes; model weights unchanged.",
        flush=True,
    )


if __name__ == "__main__":
    main()
