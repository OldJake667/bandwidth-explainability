"""Synthetic checks of mask matching and signed class-margin attribution."""

import unittest
import numpy as np
import torch
from torch import nn

from analyze_cases import black_mask, contrastive_native, gradcam


class SmallModel(nn.Module):
    def __init__(self):
        super().__init__()
        self.spatial = nn.Identity()
        self.head = nn.Linear(2, 2, bias=False)
        with torch.no_grad():
            self.head.weight.copy_(torch.tensor([[2.0, -1.0], [-3.0, -2.0]]))

    def forward(self, values):
        return self.head(self.spatial(values).mean((2, 3)))


class Tests(unittest.TestCase):
    def test_masks_match_area_and_brightness(self):
        gray = np.zeros((64, 64), dtype=np.uint8)
        a = black_mask(gray, (0, 0, 0.5, 1), (0.25, 0.5), count=30)
        b = black_mask(gray, (0.5, 0, 1, 1), (0.75, 0.5), count=30)
        self.assertEqual(a.sum(), b.sum())
        self.assertFalse(np.any(a & b))
        first, second = gray.copy(), gray.copy()
        first[a], second[b] = 255, 255
        self.assertEqual(first.mean(), second.mean())

    def test_mask_rejects_insufficient_black_pixels(self):
        with self.assertRaises(ValueError):
            black_mask(np.full((64, 64), 255, dtype=np.uint8), (0, 0, 1, 1), (0.5, 0.5), count=1)

    def test_mask_is_deterministic_and_inside_roi(self):
        gray = np.zeros((64, 64), dtype=np.uint8)
        first = black_mask(gray, (0.25, 0.25, 0.75, 0.75), (0.5, 0.5), count=21)
        second = black_mask(gray, (0.25, 0.25, 0.75, 0.75), (0.5, 0.5), count=21)
        np.testing.assert_array_equal(first, second)
        yy, xx = np.where(first)
        self.assertTrue(np.all((xx >= 16) & (xx < 48) & (yy >= 16) & (yy < 48)))

    def test_contrastive_cam_matches_analytic_margin(self):
        model = SmallModel().eval().requires_grad_(False)
        values = torch.tensor([[[[1.0, 2.0], [3.0, 4.0]], [[2.0, 1.0], [4.0, 3.0]]]])
        result = gradcam(model, model.spatial, values)
        expected = (-5 * values[0, 0] - values[0, 1]) / 4
        np.testing.assert_allclose(contrastive_native(result), expected.numpy())
        self.assertTrue(np.all(contrastive_native(result) < 0))
        self.assertFalse(model.spatial._forward_hooks)
        self.assertTrue(all(p.grad is None for p in model.parameters()))


if __name__ == "__main__":
    unittest.main(verbosity=2)
