"""Check provenance, exact masks, saved scores and rendered atlas outputs."""

import ast
import csv
import hashlib
import importlib.metadata
import json
from pathlib import Path
import re

import numpy as np
from PIL import Image
from torchvision.transforms import Resize

HERE = Path(__file__).resolve().parent
ROOT = next(p for p in HERE.parents if (p / "model-training").is_dir())


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    report = json.loads((HERE / "results.json").read_text())
    features = {
        r["file"].split("_")[0]: r
        for r in csv.DictReader((HERE.parent / "image_features.csv").open())
    }
    for row in features.values():
        assert sha256(ROOT / row["image_path"]) == row["image_sha256"]
    for relative, digest in json.loads((HERE.parent / "sources.json").read_text())[
        "local_sources_sha256"
    ].items():
        assert sha256(ROOT / relative) == digest
    for relative, digest in report["source_code_sha256"].items():
        path = ROOT / relative
        if sha256(path) != digest:
            assert path == HERE / "cases.py"
            snapshot = HERE / "executed-source/cases.py"
            assert sha256(snapshot) == digest
            assert ast.dump(ast.parse(snapshot.read_text())) == ast.dump(
                ast.parse(path.read_text())
            )

    resize = Resize((224, 224))
    cases_checked, masks_checked = 0, 0
    max_mean_range = 0.0
    detailed = []
    checkpoint_paths = {}
    for case in report["cases"]:
        sample = case["sample"]
        image = np.asarray(Image.open(ROOT / features[sample]["image_path"]).convert("L"))
        assert sha256(ROOT / features[sample]["image_path"]) == case["input_image_sha256"]
        assert case["true_label"] == (1 if case["kind"] == "TP" else 0)
        assert case["probability_high"] >= 0.5
        assert case["max_archived_probability_difference"] <= 0.0005
        assert case["hook_max_logit_difference"] <= 2e-5
        checkpoint_paths[case["model"]] = case["checkpoint_sha256"]
        arrays = np.load(HERE / "data" / sample / "maps-and-masks.npz")
        np.testing.assert_array_equal(
            arrays["contrastive_signed_native"],
            arrays["high_signed_native"] - arrays["low_signed_native"],
        )
        assert arrays["contrastive_signed_native"].shape == tuple(case["grid"])
        assert np.isfinite(arrays["contrastive_signed_upsampled"]).all()
        assert arrays["contrastive_signed_upsampled"].shape == image.shape
        means = []
        for probe in case["probes"]:
            name = probe["region"]
            mask = arrays["mask_" + name]
            assert mask.dtype == bool and mask.sum() == 4096
            assert np.all(image[mask] == 0)
            edited = image.copy()
            edited[mask] = 255
            assert edited.mean() == probe["mean_gray_after_mask"]
            probability = 1 / (1 + np.exp(-probe["logit_margin_high_minus_low"]))
            assert abs(probability - probe["probability_high"]) < 1e-6
            assert (
                abs(
                    probe["delta_margin"]
                    - (probe["logit_margin_high_minus_low"] - case["logit_margin_high_minus_low"])
                )
                < 1e-6
            )
            assert (
                abs(
                    probe["delta_probability_high_percentage_points"]
                    - 100 * (probe["probability_high"] - case["probability_high"])
                )
                < 1e-6
            )
            means.append(float(np.asarray(resize(Image.fromarray(edited))).mean()))
            detailed.append(
                {
                    "sample": sample,
                    "model": case["model"],
                    "kind": case["kind"],
                    "region": name,
                    **probe,
                }
            )
            masks_checked += 1
        assert len({p["mean_gray_after_mask"] for p in case["probes"]}) == 1
        for first, second in [("A", "B"), ("A", "C"), ("B", "C")]:
            assert not np.any(arrays["mask_" + first] & arrays["mask_" + second])
        max_mean_range = max(max_mean_range, max(means) - min(means))
        cases_checked += 1
    lab = (
        ROOT
        / "model-training/original-bandwidth-replication/undated/local-work/original_bandwidth_explainability_lab"
    )
    for model, digest in checkpoint_paths.items():
        assert sha256(lab / f"checkpoints/{model}_best_accuracy.pth") == digest
    pages = json.loads((HERE / "pages.json").read_text())
    assert len(pages) == 18
    assert pages[:2] == ["00-bandwidth-explained", "00-reading-the-figures"]
    pdf = HERE / "expanded-structural-atlas.pdf"
    assert len(re.findall(rb"/Type /Page\b", pdf.read_bytes())) == 18
    outputs = [pdf]
    for page in pages:
        for suffix in ["png", "svg"]:
            path = HERE / f"{page}.{suffix}"
            assert path.stat().st_size > 0
            if suffix == "png":
                with Image.open(path) as image:
                    image.verify()
            outputs.append(path)
    with (HERE / "mask-probe-results.csv").open("w", newline="") as stream:
        writer = csv.DictWriter(stream, fieldnames=list(detailed[0]))
        writer.writeheader()
        writer.writerows(detailed)
    verification = {
        "original_images_sha256_verified": len(features),
        "original_source_records_unchanged": True,
        "case_predictions_audited": cases_checked,
        "mask_probes_verified": masks_checked,
        "all_native_area_and_brightness_matches_exact": True,
        "maximum_resized_gray_mean_range_between_masks": max_mean_range,
        "signed_margin_linearity_arrays_verified": cases_checked,
        "synthetic_tests_passed": 4,
        "checkpoint_files_unchanged": len(checkpoint_paths),
        "model_state_unchanged_during_analysis": report["weights_unchanged"],
        "pdf_page_count": 18,
        "software": {
            name: importlib.metadata.version(name)
            for name in ["torch", "torchvision", "timm", "numpy", "scipy", "matplotlib", "Pillow"]
        },
        "outputs_sha256": {p.name: sha256(p) for p in outputs},
        "new_neural_training": False,
        "new_physical_simulations": False,
    }
    (HERE / "verification.json").write_text(json.dumps(verification, indent=2) + "\n")
    print(json.dumps({k: v for k, v in verification.items() if k != "outputs_sha256"}, indent=2))


if __name__ == "__main__":
    main()
