# A visual vocabulary for Low and High bandwidth

The [expanded structural atlas](expanded-cases/README.md), added 27 October,
covers eight varied true-positive designs, all three distinct false-positive
images across four models, enlarged structural crops, 33 new matched-area
model probes, and the full 21-image true-positive gallery.

Analysis created 26 October 2026, alongside the latest XAI update. Open
[the illustrated guide](bandwidth-pattern-guide.pdf) for real patterns, enlarged
regions, quantitative checks, the two latest error explanations, and a diagram
of how to validate a physical explanation.

This analysis uses the **original 221 bandwidth-labelled images**: 110 Low and
111 High, with the existing 176-training / 45-validation split. It is separate
from the SUTD/RDN reflection-response peak-index task. No neural model was
trained, no weights were changed, and no new electromagnetic simulations were
performed. The small one-feature thresholds below were fitted on training data.

## The closest equivalent to the dog analogy

The useful fingerprint is a combination of **coverage, fragmentation, and
continuity**, rather than one uniquely identifying point or branch.

| Visible cue | More Low-like in these images | More High-like in these images |
| --- | --- | --- |
| Overall black area | Less black area, more white space | More black area, broader structures |
| Lower branch region | Separate pieces and open gaps | A broader, more continuous arm |
| Small islands | A larger share of black area in small isolated pieces | A smaller share in small isolated pieces |
| Largest connected structure | Contains a smaller share of the black pixels | Contains a larger share |

These are tendencies, not sufficient conditions or a physical definition of
bandwidth. Black is treated as an image value: its material identity is not
inferred from the bitmap. The images are binary, so black-pixel fraction agrees
with `1 - mean_grayscale / 255` to floating-point precision.

The two main examples were selected as the validation images nearest the
**training-class median coverage**, without filtering by model correctness:

- **M196, true Low:** black coverage 13.56%, largest component 18.33% of the
  cropped black area, small-island share 16.80%.
- **M283, true High:** black coverage 25.83%, largest component 55.32%,
  small-island share 6.72%.

These examples illustrate the tendency. They do not replace the whole-dataset
checks or establish optical propagation paths.

## What the quantitative checks support

For each descriptor, its direction and threshold were selected to maximize
agreement with the 176 training labels. The same rule was then evaluated on
the existing validation partition.

| One-descriptor rule | Training agreement | Validation agreement |
| --- | --- | --- |
| High if whole-image black coverage >= 20.665% | 170/176 | 43/45 |
| High if lower-region black fraction >= 22.465% | 168/176 | 43/45 |
| High if small-island share <= 12.414% | 154/176 | 41/45 |
| High if largest-component share >= 25.664% | 158/176 | 39/45 |
| High if lower-component span >= 38.130% of cropped width | 164/176 | 38/45 |
| High if substantial-component count <= 14.5 | 119/176 | 31/45 |

Coverage reproduces the existing brightness diagnostic exactly: High if mean
grayscale <= 202.30406698564593. Training class means are 14.48% coverage for
Low and 25.38% for High. Thus a large part of the apparent discrimination is
already available to a global image statistic. A complex heatmap does not, by
itself, demonstrate that the model learned a richer optical mechanism.

Coverage and archived DINOv2 High probabilities have Spearman correlation
0.9447 on the 45 validation images. This correlation concerns model scores;
it does not show that black area causes bandwidth. Connectivity and island
descriptors also correlate with coverage, so their results do not isolate an
independent effect of topology.

All descriptors were chosen after inspecting examples and the existing
diagnostic. Training-only threshold fitting does **not** make this reused
validation set an untouched confirmatory test. The dataset is small and its
generation-family dependence has not been assessed. Accuracy here describes
this partition, not a guarantee for a new geometry or fabrication process.

## The exceptions are part of the explanation

The coverage rule fails on **M93** (true Low, coverage 23.96%) and **M178**
(true High, coverage 17.70%). A broad or dark pattern can therefore still be Low,
and a relatively light pattern can still be High.

The latest XAI slides focus on **M93 and M95**, both true Low but predicted High
by DINOv2. They explain errors rather than demonstrate correct High signatures.

- **M93:** LIME and High-class Grad-CAM highlight the long lower-right arm.
  That arm is evidence influencing a wrong model answer, not proof of High
  physical bandwidth.
- **M95:** the upper-right prongs attract High attribution, yet the design is
  labelled Low. The existing LIME surrogate estimates 38.10% High while DINOv2
  gives about 55.87%, so its local surrogate even falls on the other side of
  the classification threshold.

The saved equal-black-pixel-count mask check provides a useful control:

| Case, both true Low | Original model P(High) | Upper-right mask | Lower-left control | Target minus control |
| --- | --- | --- | --- | --- |
| M93 | 94.46% | 92.28% | 95.35% | -3.07 percentage points |
| M95 | 55.87% | 29.38% | 36.92% | -7.54 percentage points |

Both locations remove exactly 9,843 black pixels in M93 and 9,512 in M95.
Thus the two edits within a sample match native-image black area and global
brightness. Different model scores suggest position or spatial arrangement
also matters to this classifier. **Both M95 edits flip its prediction**, so the
upper-right prongs are not shown to be a uniquely decisive feature. Masking can
produce out-of-distribution designs, and no physical label was computed for
any edited image. These scores were read from the saved check, not rerun here.

## How to turn a candidate feature into a stronger explanation

1. Confirm the pixel-to-material mapping and the actual design-region scale.
2. Compare true Low and High designs with similar total black area, rather than
   selecting only visually dramatic cases or misclassified images.
3. Define one feature in advance: a gap, narrow neck, island, or continuity
   measure. Specify where and how it is measured.
4. Make matched-area edits that change that feature, with several control
   locations. Record the original and edited model logits as well as classes.
5. Compute the optical response of both modes with the original solver and
   measurement settings. Retain the complete spectra and bandwidth calculation.
6. Check the predeclared hypothesis on fresh designs or independent generation
   families. Report failures and any tradeoff with transmission or crosstalk.

The [original paper](https://doi.org/10.1002/adpr.202500284), particularly Sections
4.1 and 5.1-5.2, supplies the physical class definition and its own simulation
evidence. It supports investigating continuity and gaps; its simulations are
not a substitute for testing the present M93/M95 edits.

## Files and reproducibility

- `01-pattern-dictionary.png` / `.svg`: labelled examples and lower-region zooms.
- `02-quantitative-evidence.png` / `.svg`: all training/validation coverage
  observations, exceptions, and descriptor-rule results.
- `03-error-explanations.png` / `.svg`: original error cases, saved High-class
  Grad-CAM, and existing matched-mask scores.
- `04-validation-roadmap.png` / `.svg`: the explainability-to-physics diagram.
- `image_features.csv`: all 221 file identities, labels, split assignments,
  descriptors, image checksums, and available archived DINOv2 probabilities.
- `analysis.json`: exact feature definitions, fitted thresholds, confusion
  matrices, errors, representative-selection rule, and limitations.
- `sources.json`: primary reference and checksums of local source files.

Run `analyze_patterns.py`, `test_analyze_patterns.py`, and `build_guide.py` with
the existing original-bandwidth `.venv/bin/python -B` from this folder.
The build uses installed Matplotlib, SciPy, scikit-learn, NumPy, Pillow, and
macOS `sips`. No dependency was added to a research environment. The eight
small synthetic checks exercise blank/full coverage, disconnected/connected
components, and both threshold directions. PDF pages were rendered and visually
reviewed before delivery.
