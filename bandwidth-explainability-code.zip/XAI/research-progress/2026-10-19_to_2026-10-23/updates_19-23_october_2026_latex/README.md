# Updates: 19-23 October 2026

Eleven-slide LaTeX Beamer presentation. Compile with `tectonic presentation.tex`
or run `pdflatex presentation.tex` twice. All image assets are included.

Six completed RDN fine-tuning runs, all nine from-scratch result rows with
actual epochs run and selected checkpoint epochs,
exact published starting checkpoints, and the original six accuracy plots.
ResNet101, ResNet152 and VMamba-Base are newly completed; the three earlier
completed runs are labeled as context. Three accuracy plots share each slide.
No loss plots, footers or closing summary slide.

XAI uses the separate original bandwidth experiment and the same two DINOv2
false-High images, M93 and M95, for LIME, attention rollout, gradient attention
rollout and Grad-CAM. Each method has six panels and plain-language captions.
Grad-CAM was audited for all four original models (six errors in total).
The accompanying image-covering checks test model responses, not the physical
bandwidth of the edited geometries. Full technical details are in hidden Beamer
notes and the included JSON/CSV metadata. Source links and unchanged figure
hashes are recorded in sources.json and asset_manifest.json.
