# Updates: training results and Grad-CAM error analysis

Eleven-slide LaTeX Beamer presentation, 16--19 October 2026. No footers.
Compile with `tectonic presentation.tex` or `pdflatex presentation.tex` twice.
All figures and required assets are included. The three accuracy plots were
copied unchanged from the published fine-tuning results. Each XAI method shows
exactly two original DINOv2 errors, M93 and M95, in this order: LIME, ordinary
attention rollout, gradient attention rollout, Grad-CAM. Keeping model and
images fixed makes the methods comparable. Each method slide contains six
panels with concrete structural observations. The selected cases are both
true Low / predicted High; no false-Low cases are invented.
The original 30-epoch ResNet152 accuracy curve shows its ten-epoch
continuation. A separate slide names the exact pretrained checkpoint for all nine
fine-tuning models and records VMamba-Tiny to Base growth (29.48M to 87.53M)
with the user's current in-progress status. Ordinary rollout is class-agnostic;
gradient rollout and Grad-CAM target class logits. Figures are copied unchanged.
An additional paired white-mask score check uses the right end of the
upper-right pronged branch and an equal-black-pixel-count lower-left control.
The actual model outputs and protocol are recorded in structural_mask_checks.json.
These tests do not compute physical bandwidth for the edited geometries.

Speaker notes are embedded with Beamer `\note` commands but are not displayed
in the exported slides. Sources, exact asset hashes, tables, prediction
metadata and Grad-CAM audit records are included alongside the editable source.
The original bandwidth validation split is separate from the RDN test split.
