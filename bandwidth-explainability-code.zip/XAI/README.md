# XAI

## Progress reports

| Work period | Materials |
| --- | --- |
| 12–16 October 2026 | [Presentation](<research-progress/2026-10-12_to_2026-10-16/presentation 12 - 16.10.26.pdf>) |
| 16–19 October 2026 | [Presentation](<research-progress/2026-10-16_to_2026-10-19/presentation 16 - 19.10.26.pdf>) |
| 19–23 October 2026 | [PDF](research-progress/2026-10-19_to_2026-10-23/updates_19-23_october_2026_latex/presentation.pdf) · [LaTeX package](research-progress/2026-10-19_to_2026-10-23/updates_19-23_october_2026_latex/) · [Grad-CAM report](research-progress/2026-10-19_to_2026-10-23/updates_gradcam_latex/) |

These reports span training and explanation work. Their original contents are
preserved inside the dated folders.

The [bandwidth pattern guide](research-progress/2026-10-19_to_2026-10-23/bandwidth-pattern-guide/README.md),
created 26 October, adds real Low/High examples, visible shape descriptors,
quantitative checks, counterexamples, and a diagram for physical validation.
Its [expanded structural atlas](research-progress/2026-10-19_to_2026-10-23/bandwidth-pattern-guide/expanded-cases/README.md),
added 27 October, includes more true-positive types, every distinct false-positive
image in the original four-model validation predictions, and enlarged structural
regions with new matched-area model probes.

## Grad-CAM code and results

- [Local Grad-CAM code and results](../model-training/rdn-pretrained-finetuning/2026-10-16_to_2026-10-19/local-work/gradcam_xai/)
- [Published GitHub Grad-CAM package](../model-training/rdn-pretrained-finetuning/2026-10-16_to_2026-10-19/local-work/gradcam_xai/)

The local extracted Grad-CAM package includes additional results absent from the
old ZIP export. All extracted files were retained.

## Original-bandwidth explanation work

- [Local explainability lab: LIME and rollout notebooks](../model-training/original-bandwidth-replication/undated/local-work/original_bandwidth_explainability_lab/)
- [Published explanation results](../model-training/rdn-from-scratch/2026-10-12_to_2026-10-16/github-main/bandwidth_explainability/)

Code stays with its enclosing project to preserve data, checkpoint, and sibling
dependencies. Original-bandwidth Low/High explanation results remain distinct
from RDN compact-response training results.
