# Required model checkpoints

The model weights are retained locally and are not included in this repository.
Before running model inference or the environment notebook, copy the five files
listed in `supporting-resources.json` into this directory. Verify their SHA-256
checksums against `../package_integrity.json`. The VMamba backbone file is about
121 MB. Never substitute random weights or weights from a different task.
